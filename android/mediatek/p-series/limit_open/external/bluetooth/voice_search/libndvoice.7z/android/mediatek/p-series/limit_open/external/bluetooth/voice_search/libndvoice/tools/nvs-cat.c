#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <errno.h>
#include <libndvoice.h>


static void termination_handler(int signum)
{
    (void)signum;
    nvs_close();
    _exit(0);
}

static int install_termination_handler(void)
{
    struct sigaction sa;
    int ret;

    sa.sa_handler = termination_handler;
    sigemptyset (&sa.sa_mask);
    sa.sa_flags = 0;

    ret = sigaction(SIGINT, &sa, NULL);
    if (ret)
        return ret;

    ret = sigaction(SIGHUP, &sa, NULL);
    if (ret)
        return ret;

    ret = sigaction(SIGTERM, &sa, NULL);

    return ret;
}

int main(int argc, char **argv)
{
    uint8_t buffer[NVS_MAX_FRAME_SIZE];
    int size;
    (void)argc;
    (void)argv;
    if (install_termination_handler()) 
    {
        perror("install_termination_handler");
        return -1;
    }

    
    if ( !nvs_open() ) 
    {
        perror("nvs_open");
        return -1;
    }
    
    while (1) 
    {
        size = nvs_get_audio(buffer, NVS_MAX_FRAME_SIZE);
        if (size < 0 && size != -EAGAIN) 
        {
            nvs_close();
            return size;
        }
    }
}
