#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

#include <linux/input.h>
#include "hidraw.h"

#define DEVPATH_MAX_SIZE 64

int hidraw_open(const char *dev_name)
{
    char dev_path[DEVPATH_MAX_SIZE];
    int fd;

    snprintf(dev_path, DEVPATH_MAX_SIZE, "/dev/%s", dev_name);

    fd = open(dev_path, O_RDWR);

    return fd;
}

void hidraw_close(int fd)
{
    close(fd);
}

int hidraw_get_report(int fd, void *buffer, unsigned len)
{
    return read(fd, buffer, len);
}

int hidraw_send_report(int fd, const void *buffer, unsigned len)
{
    return write(fd, buffer, len);
}


int hidraw_get_descriptor(int fd, struct hidraw_report_descriptor *desc)
{
    int ret;

    ret = ioctl(fd, HIDIOCGRDESCSIZE, &desc->size);
    if (ret < 0)
        return ret;

    ret = ioctl(fd, HIDIOCGRDESC, desc);
    if (ret < 0)
        return ret;

    return 0;
}

int hidraw_get_devinfo(int fd, struct hidraw_devinfo *dev_info)
{
    int ret;

    ret = ioctl(fd, HIDIOCGRAWINFO, dev_info);
    if (ret < 0)
        return ret;

    return 0;
}

int hidraw_get_name(int fd, void *name, int name_len)
{
    int ret;
    
    ret = ioctl(fd, HIDIOCGRAWNAME(name_len), name);
    if (ret < 0)
        return ret;
        
    return 0;
}

const char* hidraw_bus_str(int bus)
{
    switch (bus) 
    {
    case BUS_USB:
        return "USB";
        break;
    case BUS_HIL:
        return "HIL";
        break;
    case BUS_BLUETOOTH:
        return "Bluetooth";
        break;
    case BUS_VIRTUAL:
        return "Virtual";
        break;
    default:
        return "Other";
        break;
    }
}