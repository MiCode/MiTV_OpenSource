#ifndef __LIBNVS_NVS_H__
#define __LIBNVS_NVS_H__

#ifdef __cplusplus
extern "C" {
#endif

#define NVS_MAX_FRAME_SIZE 2048
#define NVS_SAMPLE_RATE 16000

#include <inttypes.h>

struct nvs_device;

struct nvs_device *nvs_open(void);

void nvs_close();

int nvs_get_audio(uint8_t *buffer, int max_size);

int nvs_get_fd();

void nvs_print_hidraw_info(void);

int nvs_is_connected(void);

#ifdef __cplusplus
}
#endif
#endif
