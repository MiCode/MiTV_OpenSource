extern void gettimeofday(struct timeval *tv, void *tz);
