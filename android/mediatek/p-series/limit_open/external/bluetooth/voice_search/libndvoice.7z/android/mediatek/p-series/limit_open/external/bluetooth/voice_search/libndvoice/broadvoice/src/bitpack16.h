/*
 * broadvoice - a library for the BroadVoice 16 and 32 codecs
 *
 * bitpack16.h - 
 *
 * Adapted by Steve Underwood <steveu@coppice.org> from code which is
 * Copyright 2000-2009 Broadcom Corporation
 *
 * All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2.1,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: //DTV/MP_BR/DTV_X_IDTV1501_1524_1_001_28_002/android/mediatek/m-series/protect/external/bluetooth/libndvoice/broadvoice/src/bitpack16.h#1 $
 */

#if !defined(_BITPACK16_H_)
#define _BITPACK16_H_

void bv16_bitpack(uint8_t *PackedStream, struct BV16_Bit_Stream *BitStruct);
void bv16_bitunpack(const uint8_t *PackedStream, struct BV16_Bit_Stream *BitStruct);

#endif
