/*
 * (C) Copyright 2000-2004
 * Wolfgang Denk, DENX Software Engineering, wd@denx.de.
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */
#ifndef _PART_H
#define _PART_H

#include <ide.h>

#ifdef CONFIG_SYS_64BIT_LBA
#define LBAFlength "ll"
#else
#define LBAFlength "l"
#endif
#define LBAF "%" LBAFlength "x"
#define LBAFU "%" LBAFlength "u"

typedef struct block_dev_desc {
	int		if_type;	/* type of the interface */
	int		dev;		/* device number */
	unsigned char	part_type;	/* partition type */
	unsigned char	target;		/* target SCSI ID */
	unsigned char	lun;		/* target LUN */
	unsigned char	type;		/* device type */
	unsigned char	removable;	/* removable device */
#ifdef CONFIG_LBA48
	unsigned char	lba48;		/* device can use 48bit addr (ATA/ATAPI v7) */
#endif
	lbaint_t		lba;		/* number of blocks */
	unsigned long	blksz;		/* block size */
	char		vendor [40+1];	/* IDE model, SCSI Vendor */
	char		product[20+1];	/* IDE Serial no, SCSI product */
	char		revision[8+1];	/* firmware revision */
	unsigned long	(*block_read)(int dev,
				      unsigned long start,
				      lbaint_t blkcnt,
				      void *buffer);
	unsigned long	(*block_write)(int dev,
				       unsigned long start,
				       lbaint_t blkcnt,
				       const void *buffer);
    unsigned long   (*block_erase)(int dev,
                       unsigned long start,
                       lbaint_t blkcnt);
	void		*priv;		/* driver private struct pointer */
	int version_flag;
}block_dev_desc_t;

/* Interface types: */
#define IF_TYPE_UNKNOWN	0
#define IF_TYPE_IDE		1
#define IF_TYPE_SCSI	2
#define IF_TYPE_ATAPI	3
#define IF_TYPE_USB		4
#define IF_TYPE_DOC		5
#define IF_TYPE_MMC		6
#define IF_TYPE_SD		7
#define IF_TYPE_SATA	8
#define IF_TYPE_NAND	9
#define IF_TYPE_UFS		10

/* Part types */
#define PART_TYPE_UNKNOWN	0x00
#define PART_TYPE_MAC		0x01
#define PART_TYPE_DOS		0x02
#define PART_TYPE_ISO		0x03
#define PART_TYPE_AMIGA		0x04
#define PART_TYPE_EFI		0x05
#define PART_TYPE_EMMC		0x06
#define PART_TYPE_NAND		0x07
#define PART_TYPE_UFS		0x08

/*
 * Type string for U-Boot bootable partitions
 */
#define BOOT_PART_TYPE	"U-Boot"	/* primary boot partition type	*/
#define BOOT_PART_COMP	"PPCBoot"	/* PPCBoot compatibility type	*/

/* device types */
#define DEV_TYPE_UNKNOWN	0xff	/* not connected */
#define DEV_TYPE_HARDDISK	0x00	/* harddisk */
#define DEV_TYPE_TAPE		0x01	/* Tape */
#define DEV_TYPE_CDROM		0x05	/* CD-ROM */
#define DEV_TYPE_OPDISK		0x07	/* optical disk */

typedef struct disk_partition {
	long long	start;		/* # of first block in partition	*/
	long long	size;		/* number of blocks in partition	*/
	ulong	blksz;		/* block size in bytes			*/
	uchar	name[32];	/* partition name			*/
	uchar	type[32];	/* string type description		*/
} disk_partition_t;

/* Misc _get_dev functions */
block_dev_desc_t* get_dev(char* ifname, int dev);
block_dev_desc_t* ide_get_dev(int dev);
block_dev_desc_t* sata_get_dev(int dev);
block_dev_desc_t* scsi_get_dev(int dev);
block_dev_desc_t* usb_stor_get_dev(int dev);
block_dev_desc_t* mmc_get_dev(int dev);
block_dev_desc_t* ufs_get_dev(int dev);
block_dev_desc_t* sd_get_dev(int dev);
block_dev_desc_t* ftl_get_dev(int dev);
block_dev_desc_t* systemace_get_dev(int dev);
block_dev_desc_t* mg_disk_get_dev(int dev);

/* disk/part.c */
int get_partition_info (block_dev_desc_t * dev_desc, int part, disk_partition_t *info);
void print_part (block_dev_desc_t *dev_desc);
void  init_part (block_dev_desc_t *dev_desc);
void dev_print(block_dev_desc_t *dev_desc);


#ifdef CONFIG_MAC_PARTITION
/* disk/part_mac.c */
int get_partition_info_mac (block_dev_desc_t * dev_desc, int part, disk_partition_t *info);
void print_part_mac (block_dev_desc_t *dev_desc);
int   test_part_mac (block_dev_desc_t *dev_desc);
#endif

#ifdef CONFIG_EMMC_PARTITION
/* disk/part_emmc.c */
int get_partition_info_emmc (block_dev_desc_t * dev_desc, int part, disk_partition_t *info);
void print_part_emmc (block_dev_desc_t *dev_desc);
int   test_part_emmc (block_dev_desc_t *dev_desc);
int add_new_emmc_partition(block_dev_desc_t *dev_desc, disk_partition_t *info);
int remove_emmc_partition(block_dev_desc_t *dev_desc, disk_partition_t *info);
int Search_Mboot_partition_emmc (block_dev_desc_t *dev_desc);
int Search_Mpool_partition_emmc (block_dev_desc_t *dev_desc);
#ifdef CONFIG_DOUBLE_MBOOT
int Search_Mbootbak_partition_emmc (block_dev_desc_t *dev_desc);
#endif
int _get_mmc_partsize (block_dev_desc_t *dev_desc,char *puPartName,unsigned int *u32PartSize);
unsigned int get_emmc_used_blockcount(block_dev_desc_t *dev_desc);
#endif

#ifdef CONFIG_UFS_PARTITION
/* disk/part_emmc.c */
int get_partition_info_ufs (block_dev_desc_t * dev_desc, int part, disk_partition_t *info);
void print_part_ufs (block_dev_desc_t *dev_desc);
//int test_part_ufs (block_dev_desc_t *dev_desc);
int add_new_ufs_partition(block_dev_desc_t *dev_desc, disk_partition_t *info);
int remove_ufs_partition(block_dev_desc_t *dev_desc, disk_partition_t *info);
int rmgpt_ufs_partition(block_dev_desc_t *dev_desc);
int _get_ufs_partsize (block_dev_desc_t *dev_desc,char *puPartName,unsigned int *u32PartSize);
#endif

#ifdef CONFIG_DOS_PARTITION
/* disk/part_dos.c */
int get_partition_info_dos (block_dev_desc_t * dev_desc, int part, disk_partition_t *info);
void print_part_dos (block_dev_desc_t *dev_desc);
int   test_part_dos (block_dev_desc_t *dev_desc);
#endif

#ifdef CONFIG_ISO_PARTITION
/* disk/part_iso.c */
int get_partition_info_iso (block_dev_desc_t * dev_desc, int part, disk_partition_t *info);
void print_part_iso (block_dev_desc_t *dev_desc);
int   test_part_iso (block_dev_desc_t *dev_desc);
#endif

#ifdef CONFIG_AMIGA_PARTITION
/* disk/part_amiga.c */
int get_partition_info_amiga (block_dev_desc_t * dev_desc, int part, disk_partition_t *info);
void print_part_amiga (block_dev_desc_t *dev_desc);
int   test_part_amiga (block_dev_desc_t *dev_desc);
#endif

#ifdef CONFIG_EFI_PARTITION
/* disk/part_efi.c */
int get_partition_info_efi (block_dev_desc_t * dev_desc, int part, disk_partition_t *info);
void print_part_efi (block_dev_desc_t *dev_desc);
int   test_part_efi (block_dev_desc_t *dev_desc);
#endif

#endif /* _PART_H */
