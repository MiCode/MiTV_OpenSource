#ifndef GCPU_IF_H
#define GCPU_IF_H

#include "drvAESDMA.h"

typedef unsigned char*  UPTR;

typedef struct
{
    unsigned char au1Hash[32];
    unsigned char fgFirstPacket;
    unsigned char *au1WorkingBuffer;
    unsigned int u4WorkingSize;
} GCPU_SHA_HDL_T;

#define x_mem_calloc    calloc
#define x_mem_alloc     malloc
#define x_mem_realloc   realloc
#define x_mem_free      free
#define x_mem_align     memalign
#define x_memset        memset
#define x_memcpy        memcpy
#define x_memcmp        memcmp

#ifndef MI_CIPHER_HASH_BLOCK_SIZE_SHA256
#define MI_CIPHER_HASH_BLOCK_SIZE_SHA256 64
#endif

//-----------------------------------------------------------------------------
// Prototype  of public functions
//-----------------------------------------------------------------------------
extern unsigned char GCPU_LoaderInit(unsigned int u4Mode);
extern unsigned char GCPU_SHA256_Init(UPTR u4Handle, unsigned char fgIOMMU);
extern unsigned char GCPU_SHA256_Update(UPTR u4Handle, unsigned char *pu1Buf, unsigned int u4Size, MS_BOOL fgLastPacket);
extern unsigned char GCPU_SHA256_Final(UPTR u4Handle, unsigned char au1Digest[32]);
#endif  // GCPU_IF_H