/*
 * config_defaults.h - sane defaults for everyone
 *
 * Copyright (c) 2009 Analog Devices Inc.
 *
 * Licensed under the GPL-2 or later.
 */

#ifndef _CONFIG_DEFAULTS_H_
#define _CONFIG_DEFAULTS_H_

/* Support bootm-ing different OSes */
#define CONFIG_BOOTM_LINUX 1
#if CONFIG_MINIUBOOT
#else
#define CONFIG_BOOTM_NETBSD 1
#define CONFIG_BOOTM_RTEMS 1
#endif

#define CONFIG_GZIP 1
#define CONFIG_ZLIB 1

#endif
