
#include <common.h>
#include <x_ldr_env.h>
#include "maple_version_control.h"

#include "eeprom_if.h"
#include "sha256.h"

#define SHA256_HASH_SIZE    (32)

#ifdef CC_MAPLE_LOADER_UPGRADE_VERSION_CTRL_FLOW
#ifdef SONY_PKG_TYPE_EXTENSION
#define LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR     0x10600 //from L to H
#else /*SONY_PKG_TYPE_EXTENSION*/
#define LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR     0xB420 //from L to H
#endif /*SONY_PKG_TYPE_EXTENSION*/
#define LOADER_UPGRADE_CFG_PKG_VERSION_INFO_SIZE    0x40
#define LOADER_UPGRADE_CFG_PKG_UID_ADDR             LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR //from H to L
#define LOADER_UPGRADE_CFG_UID_SIZE                 12
#define LOADER_UPGRADE_CFG_PKG_EMID_ADDR            LOADER_UPGRADE_CFG_PKG_UID_ADDR+LOADER_UPGRADE_CFG_UID_SIZE+1 //from H to L
#define LOADER_UPGRADE_CFG_EMID_SIZE                8
#define LOADER_UPGRADE_CFG_PKG_VERSION_ADDR         LOADER_UPGRADE_CFG_PKG_EMID_ADDR+LOADER_UPGRADE_CFG_EMID_SIZE+1 //from L to H
#ifdef CC_SONY_PKG_VERSION_EXTENSION
#define LOADER_UPGRADE_CFG_PKG_VERSION_SIZE         10
#else /*SONY_PKG_TYPE_EXTENSION*/
#define LOADER_UPGRADE_CFG_PKG_VERSION_SIZE          4
#endif /*SONY_PKG_TYPE_EXTENSION*/
#define LOADER_UPGRADE_CFG_PKG_BROADCAST_ADDR       LOADER_UPGRADE_CFG_PKG_VERSION_ADDR+LOADER_UPGRADE_CFG_PKG_VERSION_SIZE
#define LOADER_UPGRADE_CFG_PKG_BROADCAST_SIZE       4
#define LOADER_UPGRADE_CFG_PKG_HMAC_ADDR            LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR+LOADER_UPGRADE_CFG_PKG_VERSION_INFO_SIZE //from H to L
#define LOADER_UPGRADE_CFG_PKG_HMAC_SIZE            0x20

extern int mtk_hmac_sha256(uint8_t *key, uint32_t key_size, uint8_t *msg, uint32_t msg_size,
                    uint8_t result[SHA256_HASH_SIZE]);

//return 0-locked, 1-unlocked.
int get_console_state(void)
{
    LDR_ENV_T *prLdrEnv = (LDR_ENV_T *)CC_LDR_ENV_OFFSET;
    return prLdrEnv->Isconsolelocked;
}

static int _uBootVersionHmacGen(UINT8 *Data_in, UINT8 *Hmac_out, UINT32 Data_in_size)
{
    LDR_ENV_T *prLdrEnv = (LDR_ENV_T *)CC_LDR_ENV_OFFSET;
    mtk_hmac_sha256(prLdrEnv->versionHmacKey, sizeof(prLdrEnv->versionHmacKey), Data_in, Data_in_size, Hmac_out);
    printf("%s, Hmac generation done.\n",__FUNCTION__);
    return 0;
}

static int  _uBootVersionHmacCompare(UINT8 *Data_in, UINT8 *Hmac_in, UINT32 Data_in_size)
{
    LDR_ENV_T *prLdrEnv = (LDR_ENV_T *)CC_LDR_ENV_OFFSET;
    UINT8 arHmacOut[32];

    mtk_hmac_sha256(prLdrEnv->versionHmacKey, sizeof(prLdrEnv->versionHmacKey), Data_in, Data_in_size, arHmacOut);

    if (memcmp(Hmac_in, arHmacOut, 32) != 0)
    {
        printf("%s, Version Hmac Compare not match!!\n",__FUNCTION__);
        return -1;
    }
    printf("%s, Compare Done.\n",__FUNCTION__);
    return 0;
}

static void Dec64ToStr(char *pszStr, int strLength, uint64_t DecValue)
{
    int i;
    char digit = 0;

    //0xFFFFFFFFFFFFFFFF = 18446744073709551615
    if (strLength > 20) {
        strLength = 20;
    }

    pszStr[strLength] = '\0';
    for(i = strLength - 1; i >= 0; i--)
    {
        digit = (char)(DecValue % 10);
        pszStr[i] = digit + '0';
        DecValue /= 10;
    }
}

void update_pkg_cfg_version(uint64_t version_dec)
{
    char version_string[LOADER_UPGRADE_CFG_PKG_VERSION_SIZE+LOADER_UPGRADE_CFG_PKG_BROADCAST_SIZE+1] = {0};
    char *pVerStr = version_string;

    UINT8 szTmp[LOADER_UPGRADE_CFG_PKG_VERSION_INFO_SIZE+LOADER_UPGRADE_CFG_PKG_HMAC_SIZE];

    uint8_t* pOnBoardVerInfo = &szTmp[0];
    uint8_t* pVerInfoHmac = &szTmp[LOADER_UPGRADE_CFG_PKG_HMAC_ADDR-LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR];

    char szOldVersionID[LOADER_UPGRADE_CFG_PKG_VERSION_SIZE+1] = {0};
    char szOldBroadcastID[LOADER_UPGRADE_CFG_PKG_BROADCAST_SIZE+1] = {0};

    char szNewVersionID[LOADER_UPGRADE_CFG_PKG_VERSION_SIZE+1] = {0};
    char szNewBroadcastID[LOADER_UPGRADE_CFG_PKG_BROADCAST_SIZE+1] = {0};

    // read old version information and HMAC
    UNUSED(EEPROM_Read(LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR,
                        (UPTR)(VOID *)&szTmp[0], LOADER_UPGRADE_CFG_PKG_VERSION_INFO_SIZE+LOADER_UPGRADE_CFG_PKG_HMAC_SIZE));

    #if defined(CC_SECURESTORAGE_SUPPORT)
    if(0 == _uBootVersionHmacCompare(pOnBoardVerInfo, pVerInfoHmac, LOADER_UPGRADE_CFG_PKG_VERSION_INFO_SIZE))
    #else
    if(1)
    #endif
    {
        strncpy(szOldVersionID, pOnBoardVerInfo+(LOADER_UPGRADE_CFG_PKG_VERSION_ADDR-LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR), LOADER_UPGRADE_CFG_PKG_VERSION_SIZE);
        strncpy(szOldBroadcastID, pOnBoardVerInfo+(LOADER_UPGRADE_CFG_PKG_BROADCAST_ADDR-LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR), LOADER_UPGRADE_CFG_PKG_BROADCAST_SIZE);

        printf("%s, Old Version ID: %s\n",__FUNCTION__,szOldVersionID);
        printf("%s, Old Broadcast ID: %s\n",__FUNCTION__,szOldBroadcastID);

        Dec64ToStr(pVerStr, LOADER_UPGRADE_CFG_PKG_VERSION_SIZE+LOADER_UPGRADE_CFG_PKG_BROADCAST_SIZE, version_dec);

        strncpy(szNewVersionID,pVerStr,LOADER_UPGRADE_CFG_PKG_VERSION_SIZE);
        pVerStr += LOADER_UPGRADE_CFG_PKG_VERSION_SIZE;
        strncpy(szNewBroadcastID,pVerStr,LOADER_UPGRADE_CFG_PKG_BROADCAST_SIZE);

        printf("%s, New Version ID: %s\n",__FUNCTION__,szNewVersionID);
        printf("%s, New Broadcast ID: %s\n",__FUNCTION__,szNewBroadcastID);

        if(strcmp(szOldVersionID, szNewVersionID) != 0 || strcmp(szOldBroadcastID, szNewBroadcastID) != 0)
        {
            // update new version information
            strncpy(pOnBoardVerInfo+(LOADER_UPGRADE_CFG_PKG_VERSION_ADDR-LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR),
                (UPTR)(void *)&szNewVersionID[0], LOADER_UPGRADE_CFG_PKG_VERSION_SIZE);
            strncpy(pOnBoardVerInfo+(LOADER_UPGRADE_CFG_PKG_BROADCAST_ADDR-LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR),
                (UPTR)(void *)&szNewBroadcastID[0], LOADER_UPGRADE_CFG_PKG_BROADCAST_SIZE);

            //store HMAC
        #if defined(CC_SECURESTORAGE_SUPPORT)
            UNUSED(_uBootVersionHmacGen(pOnBoardVerInfo, pVerInfoHmac,LOADER_UPGRADE_CFG_PKG_VERSION_INFO_SIZE));
            UNUSED(EEPROM_Write(LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR,
                                (UPTR)(void *)&szTmp[0],LOADER_UPGRADE_CFG_PKG_VERSION_INFO_SIZE+LOADER_UPGRADE_CFG_PKG_HMAC_SIZE));
            #ifdef CC_EEP2EMMC_DUAL_BANK_SUPPORT
            // Must Write Twice.
            UNUSED(EEPROM_Write(LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR,
                                (UPTR)(void *)&szTmp[0],LOADER_UPGRADE_CFG_PKG_VERSION_INFO_SIZE+LOADER_UPGRADE_CFG_PKG_HMAC_SIZE));
            #endif
        #else
            UNUSED(EEPROM_Write(LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR,
                                (UPTR)(void *)&szTmp[0],LOADER_UPGRADE_CFG_PKG_VERSION_INFO_SIZE));
            #ifdef CC_EEP2EMMC_DUAL_BANK_SUPPORT
            // Must Write Twice.
            UNUSED(EEPROM_Write(LOADER_UPGRADE_CFG_PKG_VERSION_INFO_ADDR,
                                (UPTR)(void *)&szTmp[0],LOADER_UPGRADE_CFG_PKG_VERSION_INFO_SIZE));
            #endif
        #endif
            printf("%s, Done.\n",__FUNCTION__);
        }
        else
        {
            printf("%s, No need to update.\n",__FUNCTION__);
        }
    }
    else
    {
        printf("%s, Fail.\n",__FUNCTION__);
    }
}

#endif

