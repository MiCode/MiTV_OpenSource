/* SHA-256 and SHA-512 implementation based on code by Oliver Gay
 * <olivier.gay@a3.epfl.ch> under a BSD-style license. See below.
 */

/*
 * FIPS 180-2 SHA-224/256/384/512 implementation
 * Last update: 02/02/2007
 * Issue date:  04/30/2005
 *
 * Copyright (C) 2005, 2007 Olivier Gay <olivier.gay@a3.epfl.ch>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the project nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE PROJECT AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include "avb_sha.h"
#include "gcpu_if.h"

static GCPU_SHA_HDL_T gcpu_ctx;

/* SHA-256 implementation */
void avb_sha256_init(AvbSHA256Ctx* ctx) {
  /* ctx->h[] is not used when using gcpu */
  ctx->len = 0;
  ctx->tot_len = 0;

  /* initial gcpu hardware */
  GCPU_Init(0);
  /* initial gcpu_ctx */
  GCPU_SHA256_Init(&gcpu_ctx, false);
}

void avb_sha256_update(AvbSHA256Ctx* ctx, const uint8_t* data, uint32_t len) {
  unsigned int block_nb;
  unsigned int new_len, rem_len, tmp_len;
  const uint8_t* shifted_data;

  if (len == 0) {
    return;
  }

  tmp_len = 2*AVB_SHA256_BLOCK_SIZE - ctx->len;
  rem_len = len < tmp_len ? len : tmp_len;

  avb_memcpy(&ctx->block[ctx->len], data, rem_len);

  if (ctx->len + len < 2*AVB_SHA256_BLOCK_SIZE) {
    ctx->len += len;
    return;
  }

  new_len = len - rem_len;
  block_nb = new_len / AVB_SHA256_BLOCK_SIZE;

  if (block_nb > 0) {
    // Ensure at the final state, the ctx->len is not zero.
    block_nb -= 1;
  }

  shifted_data = data + rem_len;

  GCPU_SHA256_Update(&gcpu_ctx, ctx->block, 2*AVB_SHA256_BLOCK_SIZE, false);

  if (block_nb > 0) {
    GCPU_SHA256_Update(&gcpu_ctx, shifted_data, block_nb*AVB_SHA256_BLOCK_SIZE, false);
  }

  rem_len = new_len - block_nb*AVB_SHA256_BLOCK_SIZE;

  avb_memcpy(ctx->block, &shifted_data[block_nb << 6], rem_len);

  ctx->len = rem_len;
  ctx->tot_len += (block_nb + 2) << 6;
}

uint8_t* avb_sha256_final(AvbSHA256Ctx* ctx) {

  GCPU_SHA256_Update(&gcpu_ctx, ctx->block, ctx->len, true);
  GCPU_SHA256_Final(&gcpu_ctx, ctx->buf);

  return ctx->buf;
}

