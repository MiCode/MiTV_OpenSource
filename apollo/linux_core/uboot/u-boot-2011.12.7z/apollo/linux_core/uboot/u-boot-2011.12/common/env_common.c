/*
 * (C) Copyright 2000-2010
 * Wolfgang Denk, DENX Software Engineering, wd@denx.de.
 *
 * (C) Copyright 2001 Sysgo Real-Time Solutions, GmbH <www.elinos.com>
 * Andreas Heppel <aheppel@sysgo.de>
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

#include <common.h>
#include <command.h>
#include <environment.h>
#include <linux/stddef.h>
#include <search.h>
#include <errno.h>
#include <malloc.h>
#include "x_bim.h"
#include <version.h>
#include "eeprom_if.h"
#include "feature_tbl.h"
#include "x_hal_5381.h"

#define CC_UBOOT_TRANSFER_USBGPIO_KERNEL
#ifdef CC_S_PLATFORM
#define CC_UBOOT_TRANSFER_UART_MODE
#endif
#define CC_UBOOT_TRANSFER_MSDCGPIO_KERNEL

#if defined(CC_KERNEL_HS200_SUPPORT) || defined(CC_KERNEL_HS400_SUPPORT)
#define CC_UBOOT_TRANSFER_MSDC_AUTOK_KERNEL 1
#else
#define CC_UBOOT_TRANSFER_MSDC_AUTOK_KERNEL 0
#endif

#include "drvcust_if.h"

//#ifdef CC_S_PLATFORM
#include "x_ldr_env.h"
//#endif

#ifdef CC_CMDLINE_UPGRADE_STATUS
#include "x_ldr_env.h"
#endif

#ifdef CC_LOADER_LOGO_LONG_TIME
#include "x_ldr_env.h"
#endif
DECLARE_GLOBAL_DATA_PTR;

/************************************************************************
 * Default settings to be used when no valid environment is found
 */
#define XMK_STR(x)	#x
#define MK_STR(x)	XMK_STR(x)

const uchar default_environment[] = {
#ifdef	CONFIG_BOOTARGS
	"bootargs="	CONFIG_BOOTARGS			"\0"
#endif
#ifdef	CONFIG_EMMCLOG
	"emmclog="	CONFIG_EMMCLOG			"\0"
#endif
#ifdef	CONFIG_BOOTCOMMAND
	"bootcmd="	CONFIG_BOOTCOMMAND		"\0"
#endif
#ifdef	CONFIG_RAMBOOTCOMMAND
	"ramboot="	CONFIG_RAMBOOTCOMMAND		"\0"
#endif
#ifdef	CONFIG_NFSBOOTCOMMAND
	"nfsboot="	CONFIG_NFSBOOTCOMMAND		"\0"
#endif
#if defined(CONFIG_BOOTDELAY) && (CONFIG_BOOTDELAY >= 0)
	"bootdelay="	MK_STR(CONFIG_BOOTDELAY)	"\0"
#endif
#if defined(CONFIG_BAUDRATE) && (CONFIG_BAUDRATE >= 0)
	"baudrate="	MK_STR(CONFIG_BAUDRATE)		"\0"
#endif
#ifdef	CONFIG_LOADS_ECHO
	"loads_echo="	MK_STR(CONFIG_LOADS_ECHO)	"\0"
#endif
#ifdef	CONFIG_ETHADDR
	"ethaddr="	MK_STR(CONFIG_ETHADDR)		"\0"
#endif
#ifdef	CONFIG_ETH1ADDR
	"eth1addr="	MK_STR(CONFIG_ETH1ADDR)		"\0"
#endif
#ifdef	CONFIG_ETH2ADDR
	"eth2addr="	MK_STR(CONFIG_ETH2ADDR)		"\0"
#endif
#ifdef	CONFIG_ETH3ADDR
	"eth3addr="	MK_STR(CONFIG_ETH3ADDR)		"\0"
#endif
#ifdef	CONFIG_ETH4ADDR
	"eth4addr="	MK_STR(CONFIG_ETH4ADDR)		"\0"
#endif
#ifdef	CONFIG_ETH5ADDR
	"eth5addr="	MK_STR(CONFIG_ETH5ADDR)		"\0"
#endif
#ifdef	CONFIG_IPADDR
	"ipaddr="	MK_STR(CONFIG_IPADDR)		"\0"
#endif
#ifdef	CONFIG_SERVERIP
	"serverip="	MK_STR(CONFIG_SERVERIP)		"\0"
#endif
#ifdef	CONFIG_SYS_AUTOLOAD
	"autoload="	CONFIG_SYS_AUTOLOAD		"\0"
#endif
#ifdef	CONFIG_PREBOOT
	"preboot="	CONFIG_PREBOOT			"\0"
#endif
#ifdef	CONFIG_ROOTPATH
	"rootpath="	CONFIG_ROOTPATH			"\0"
#endif
#ifdef	CONFIG_GATEWAYIP
	"gatewayip="	MK_STR(CONFIG_GATEWAYIP)	"\0"
#endif
#ifdef	CONFIG_NETMASK
	"netmask="	MK_STR(CONFIG_NETMASK)		"\0"
#endif
#ifdef	CONFIG_HOSTNAME
	"hostname="	MK_STR(CONFIG_HOSTNAME)		"\0"
#endif
#ifdef	CONFIG_BOOTFILE
	"bootfile="	CONFIG_BOOTFILE			"\0"
#endif
#ifdef	CONFIG_LOADADDR
	"loadaddr="	MK_STR(CONFIG_LOADADDR)		"\0"
#endif
#ifdef	CONFIG_CLOCKS_IN_MHZ
	"clocks_in_mhz=1\0"
#endif
#if defined(CONFIG_PCI_BOOTDELAY) && (CONFIG_PCI_BOOTDELAY > 0)
	"pcidelay="	MK_STR(CONFIG_PCI_BOOTDELAY)	"\0"
#endif
#ifdef	CONFIG_EXTRA_ENV_SETTINGS
	CONFIG_EXTRA_ENV_SETTINGS
#endif
	"\0"
};
extern char mtdparts_default[];

struct hsearch_data env_htab;
//int default_environment_size = sizeof(default_environment);
int default_environment_size = 0x2000;
static unsigned int kmemsize = 0;
static unsigned int kmemstart2_high = 0;
static unsigned int kmemstart2_low = 0;
static unsigned int kmemsize2 = 0;
static unsigned int kmemsize2_4G = 0;
static unsigned int kmemsize2_3_5G = 0;
static unsigned int kmemsize2_3G = 0;
static unsigned int kmem2start = 0;
static unsigned int kmem2size = 0;
static unsigned int kmem3start = 0;
static unsigned int kmem3size = 0;
#ifdef CC_FBM_DYNMJC
static unsigned int kmemsize_nomjc = 0;
#endif

#if defined(CC_DYNAMIC_FBMSRM_CONF)
static unsigned int kmem4ksize = 0;
static unsigned int kmemfhdsize = 0;
static unsigned int kmem24ksize = 0;
static unsigned int kmem2fhdsize = 0;
static unsigned int gpu4kstart = 0;
static unsigned int gpufhdstart = 0;
static unsigned int gpu4ksize = 0;
static unsigned int gpufhdsize = 0;
static unsigned int gpu4kionsize = 0;
static unsigned int gpufhdionsize = 0;
#endif

#ifdef CC_RAMOOPS_SUPPORT
static unsigned int RamoopsMemAddress = 0;
#endif

static uchar env_get_char_init(int index)
{
	/* if crc was bad, use the default environment */
	if (gd->env_valid)
		return env_get_char_spec(index);
	else
		return default_environment[index];
}

uchar env_get_char_memory(int index)
{
	return *env_get_addr(index);
}

uchar env_get_char(int index)
{
	/* if relocated to RAM */
	if (gd->flags & GD_FLG_RELOC)
		return env_get_char_memory(index);
	else
		return env_get_char_init(index);
}

const uchar *env_get_addr(int index)
{
	if (gd->env_valid)
		return (uchar *)(gd->env_addr + index);
	else
		return &default_environment[index];
}

extern void env_add_bootargs(char* oldstr, char* newstr);

uint8_t env_get_bootargs(const char* key, char* value)
{
    char *p1 = NULL, *p2 = NULL;
    char *bootargs = NULL;
    int value_strlen = 0;

    bootargs = getenv("bootargs");
    if(bootargs == NULL || key == NULL)
    {
        return 0; //false, get the key string fail.
    }
    p1 = strstr(bootargs, key);
    if(p1 == NULL)
    {
        return 0; //false, get the key string fail.
    }

    p1 += strlen(key);
    if(*p1 == '=')
    {
        p1++;
        if(*p1 == '\"')
        {
            p2 = strstr(p1+1,"\" ");
            if(p2 != NULL)
            {
                value_strlen = p2-p1+1;
                strncpy(value,p1,value_strlen);
                value[value_strlen] = '\0';
            }
        }
        else
        {
            p2 = strstr(p1," ");
            if(p2 != NULL)
            {
                value_strlen = p2-p1;
                strncpy(value,p1,value_strlen);
                value[value_strlen] = '\0';
            }
        }
    }
    return 1;//true, get the key string OK.
}

void print_bootargs_size(void)
{
    char *bootargs = NULL;
    bootargs = getenv("bootargs");
    printf("\n## uBoot bootargs size is limited: %d Bytes, current size: %d Bytes.\n\n",
            COMMAND_LINE_SIZE, strlen(bootargs));
}

#ifdef CC_UBOOT_ADD_USB_ETH_MODE
static void env_add_usb_eth(void)
{
	char usbEthCtrl[16] = {0};
	char usbEthPort[] = "adb_port=0";//always using usb port 0 for vitual Ethernet port in FY17

	unsigned int u4IsUsbEth = 0;
    Printf("+[env_add_usb_eth]\n");
    // adb_enalbe  -> arch/arm/mach-mt53xx/core.c/ssusb_adb_flag to set host/device mode
	if((0==DRVCUST_InitQuery(eFlagIsUsbEthMode, &u4IsUsbEth)) && u4IsUsbEth)
	{
		sprintf(usbEthCtrl, "adb_enable=%d", u4IsUsbEth);
        Printf("+[env_add_usb_eth]1 %s, %s \n", usbEthCtrl, usbEthPort);
		env_add_bootargs("adb_enable=", usbEthCtrl);
		env_add_bootargs("adb_port=", usbEthPort);
	}     
    else 
    {
        sprintf(usbEthCtrl, "adb_enable=%d", 0);
        Printf("+[env_add_usb_eth]2 %s, %s \n", usbEthCtrl, usbEthPort);
		env_add_bootargs("adb_enable=", usbEthCtrl);
    }
}
#endif
#if defined(CC_UBOOT_ADD_USB_LOG_MODE)
#ifdef CC_S_PLATFORM
static void env_add_usb_log(void)
{
	#if defined(CC_LMP_CUST) || defined(CC_PHX_CUST)
	char usbSerialConsole[] = "console=ttyUSB0,115200n1";
	#else
    char usbSerialConsole[] = "console=ttyMT0,115200n1 console=ttyUSB0,115200n1";
	#endif
    char uartSerialConsole[] = "console=ttyMT0,115200n1";
    unsigned int u4IsUsbLog=0;
    if((0==DRVCUST_InitQuery(eFlagIsUsbLogMode, &u4IsUsbLog)) && u4IsUsbLog)
        {
        env_add_bootargs("console=", usbSerialConsole);
        }
    else
    {
        env_add_bootargs("console=", uartSerialConsole);
    }
}
#else
extern int EEPROM_Read(uint64_t u8Offset, int u4MemPtr, int u4MemLen);
static void env_add_usb_log(void)
{
    char u1FactMode = 0;
    char usbserialconsole[] = "console=ttyUSB0,115200n1";

    if (0 == EEPROM_Read(CC_UBOOT_ADD_USB_LOG_MODE_ADDR, (int)(void*)&u1FactMode, sizeof(char)))
    {
        if (u1FactMode == 1)
        {
            env_add_bootargs(NULL, usbserialconsole);
        }
    }
}
#endif
#endif

#ifdef CC_ENABLE_MTK_MODEL_INDEX
extern unsigned int GetCurrentPanelIndex(void);
#endif
static void env_add_panel_index(void)
{
    char newstr[32] = {0};

#ifdef CC_ENABLE_MTK_MODEL_INDEX
    sprintf(newstr, "modelindex_id=%d", GetCurrentPanelIndex());
#else
    sprintf(newstr, "modelindex_id=%d", GetModelIndexFromEEPROM());
#endif // CC_ENABLE_MTK_MODEL_INDEX
    env_add_bootargs("modelindex_id=", newstr);
}


#ifdef CC_ENABLE_MALI_CORE_NUM
extern unsigned int Efuse_MaliMaliCoreNum(void);
static void env_add_mali_core_num(void)
{
    char newstr[32] = {0};

    sprintf(newstr, "mali_core_num=%d", Efuse_MaliMaliCoreNum());
    env_add_bootargs("mali_core_num=", newstr);
}
#endif
#ifdef CC_SUPPORT_CHIPID

static void env_add_chipid(void)
{
    char newstr[64] = {0};
	sprintf(newstr, "androidboot.hardware=mt%x", (*((volatile u32*)(IO_VIRT+0x0000d064)))>>16);
    env_add_bootargs("androidboot.hardware=", newstr);
}
#endif
#ifdef CC_S_PLATFORM
#ifdef CC_UBOOT_TRANSFER_UART_MODE
static void env_add_uart_mode(void)
{
	int val=0;
	char str[32] = {0};
	EEPROM_Read((UINT64)0x6c8, (UINT32)&val, (UINT32)sizeof(char));//val = 3 VDA 4 Locatel
	sprintf(str, "uart_mode=%d",val);
	env_add_bootargs("uart_mode=", str);

}
#endif
#endif
#ifdef SYS_C4TV_SUPPORT

static void env_add_dual_partition(void)
{
    DTVCFG_T rDtvCfg;
    UBOOT_EEPDTV_GetCfg(&rDtvCfg);
    if ((rDtvCfg.u1Flags7 & DTVCFG_FLAG7_DUAL_BANK_CAST_SYSTEM) == DTVCFG_FLAG7_DUAL_BANK_CAST_SYSTEM)
    	{
			env_add_bootargs("system=", "system=1");
    	}
	else
		{
			env_add_bootargs("system=", "system=0");
		}
	
    if ((rDtvCfg.u1Flags7 & DTVCFG_FLAG7_DUAL_BANK_3RD) == DTVCFG_FLAG7_DUAL_BANK_3RD)
    	{
			env_add_bootargs("3rd_ro=", "3rd_ro=1");
    	}
	else
		{
			env_add_bootargs("3rd_ro=", "3rd_ro=0");
		}

    if ((rDtvCfg.u1Flags7 & DTVCFG_FLAG7_DUAL_BANK_CHROME) == DTVCFG_FLAG7_DUAL_BANK_CHROME)
    	{
    		env_add_bootargs("chrome=", "chrome=1");
    	}
    else
    	{
    		env_add_bootargs("chrome=", "chrome=0");
    	}
    if ((rDtvCfg.u1Flags7 & DTVCFG_FLAG7_DUAL_BANK_ROOTFS) == DTVCFG_FLAG7_DUAL_BANK_ROOTFS)
	{
		env_add_bootargs("linux_rootfs=", "linux_rootfs=1");
	}
    else
	{
		env_add_bootargs("linux_rootfs=", "linux_rootfs=0");
	}	
}
#endif
#ifdef CC_KERNEL_NO_LOG

static void env_add_forbid_uart(void)
{
    char *print = getenv("print");

    if (print == NULL)
    {
        // default disable kernel log
        print = "off";
        setenv("print", print);
    }
    if (!strcmp(print, "off"))
    {
        env_add_bootargs("forbid_uart0=", "forbid_uart0=1");
    }
    else
    {
        env_add_bootargs("forbid_uart0=", "forbid_uart0=0");
    }
}
#endif


static void env_add_uart_perfor(void)
{
    char new_str[32] = {0};
    unsigned int new_uint = ~0U;
    char *perfor = getenv("uart_perfor");

    if (perfor == NULL)
    {
        #ifdef CC_S_PLATFORM
        perfor = "dma_tx";
        #else
        perfor = "swfifo_tx";
        #endif
        setenv("uart_perfor", perfor);
    }

    if (!strcmp(perfor, "dma_tx"))
    {
        new_uint = 0x13;
    }
    else if (!strcmp(perfor, "swfifo_tx"))
    {
        new_uint = 0x12;
    }
    else if (!strcmp(perfor, "raw_tx"))
    {
        new_uint = 0x11;
    }
    else if (!strcmp(perfor, "swfifo_dma_tx"))
    {
        new_uint = 0x12 + (0x01 << 28);
    }
    else if (!strcmp(perfor, "raw_dma_tx"))
    {
        new_uint = 0x11 + (0x01 << 28);
    }
    else if (!strcmp(perfor, "off"))
    {
        new_uint = 0x0;
    }

    if (~0U != new_uint)
    {
        sprintf(new_str, "uartp_mode=%u", new_uint);
        env_add_bootargs("uartp_mode=", new_str);
    }
}


#ifdef CC_ENABLE_CMA_SUPPORT
static void env_add_cmaCHA_startaddress(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHA_startaddress=%d", ((PHYS_CMA_SDRAM_1) >>20)); // MByte
    env_add_bootargs("cmaCHA_startaddress=", newstr);
}
static void env_add_cmaCHA_size(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHA_size=%d", ((PHYS_CMA_SDRAM_1_SIZE) >>20)); // MByte
    env_add_bootargs("cmaCHA_size=", newstr);
}
static void env_del_cmaCHA_startaddress(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHA_startaddress=%d", 0);
    env_add_bootargs("cmaCHA_startaddress=", newstr);
}
static void env_del_cmaCHA_size(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHA_size=%d", 0);
    env_add_bootargs("cmaCHA_size=", newstr);
}

#if CONFIG_NR_DRAM_BANKS>1
static void env_add_cmaCHB_startaddress(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHB_startaddress=%d", ((PHYS_CMA_SDRAM_2) >> 20));//MByte
    env_add_bootargs("cmaCHB_startaddress=", newstr);
}
static void env_add_cmaCHB_size(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHB_size=%d", ((PHYS_CMA_SDRAM_2_SIZE) >> 20));//MByte
    env_add_bootargs("cmaCHB_size=", newstr);
}

static void env_del_cmaCHB_startaddress(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHB_startaddress=%d", 0);
    env_add_bootargs("cmaCHB_startaddress=", newstr);
}
static void env_del_cmaCHB_size(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHB_size=%d", 0);
    env_add_bootargs("cmaCHB_size=", newstr);
}

#endif

#if defined(CC_SUPPORT_CHANNEL_C)
static void env_add_cmaCHC_startaddress(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHC_startaddress=%d", ((PHYS_CMA_SDRAM_3) >> 20));//MByte
    env_add_bootargs("cmaCHC_startaddress=", newstr);
}
static void env_add_cmaCHC_size(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHC_size=%d", ((PHYS_CMA_SDRAM_3_SIZE) >> 20));//MByte
    env_add_bootargs("cmaCHC_size=", newstr);
}
static void env_del_cmaCHC_startaddress(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHC_startaddress=%d", 0);
    env_add_bootargs("cmaCHC_startaddress=", newstr);
}
static void env_del_cmaCHC_size(void)
{
    char newstr[32] = {0};
    sprintf(newstr, "cmaCHC_size=%d", 0);
    env_add_bootargs("cmaCHC_size=", newstr);
}

#endif
#endif

#ifdef CC_VP9_SUPPORT
static void env_add_vp9_support(void)
{
	char newstr[26] = {0};
	sprintf(newstr, "androidboot.vp9_support=%d", 1);
	env_add_bootargs("androidboot.vp9_support=", newstr);
}
#endif

static void env_add_gpu_addr(void)
{
	char newstr[16] = {0};
#if defined(CC_DYNAMIC_FBMSRM_CONF)
	if(FBMDynIs4KMode())
		sprintf(newstr, "gpustart=%s", getenv("gpu4kstart"));
	else
		sprintf(newstr, "gpustart=%s", getenv("gpufhdstart"));
#else
	sprintf(newstr, "gpustart=%d", PHYS_GPU_START);
#endif
	env_add_bootargs("gpustart=", newstr);

#if defined(CC_DYNAMIC_FBMSRM_CONF)
	if(FBMDynIs4KMode())
		sprintf(newstr, "gpusize=%s", getenv("gpu4ksize"));
	else
		sprintf(newstr, "gpusize=%s", getenv("gpufhdsize"));
#else
	sprintf(newstr, "gpusize=%d", PHYS_GPU_SIZE);
#endif
	env_add_bootargs("gpusize=", newstr);

#if defined(CC_DYNAMIC_FBMSRM_CONF)
	if(FBMDynIs4KMode())
		sprintf(newstr, "gpuionsize=%s", getenv("gpu4kionsize"));
	else
		sprintf(newstr, "gpuionsize=%s", getenv("gpufhdionsize"));
#else
	sprintf(newstr, "gpuionsize=%d", PHYS_GPU_ION_SIZE);
#endif
	env_add_bootargs("gpuionsize=", newstr);
}
#ifdef CC_S_PLATFORM
#if defined(CC_OX_CUST) || defined(CC_WK_CUST) || defined(CC_HK_CUST)
extern unsigned int UBOOT_EEP_GetSerial(void);
#endif
#endif

static void env_add_usb_serialno(void)
{
    char newstr[50] = {0};
	#ifdef CC_S_PLATFORM
	#if defined(CC_OX_CUST) || defined(CC_WK_CUST) || defined(CC_HK_CUST)
	char *serialstr;

	serialstr = UBOOT_EEP_GetSerial();
	//Printf("env_add_usb_serialno(%s)\n",serialstr);
    sprintf(newstr, "androidboot.serialno=%s", serialstr);
    env_add_bootargs("androidboot.serialno=", newstr);
  #else
	#define ETHERNET_BASE1	(IO_VIRT+0x00032014)
	#define ETHERNET_BASE2	(IO_VIRT+0x00032018)
    sprintf(newstr, "androidboot.serialno=%08x%08x", (*((volatile u32*)(ETHERNET_BASE1))),(*((volatile u32*)(ETHERNET_BASE2))));
    env_add_bootargs("androidboot.serialno=", newstr);
  #endif
	#else
	#define ETHERNET_BASE1	(IO_VIRT+0x00032014)
	#define ETHERNET_BASE2	(IO_VIRT+0x00032018)
    sprintf(newstr, "androidboot.serialno=%08x%08x", (*((volatile u32*)(ETHERNET_BASE1))),(*((volatile u32*)(ETHERNET_BASE2))));
    env_add_bootargs("androidboot.serialno=", newstr);
	#endif
}

#ifdef CC_ANDROID_SECURE_BOOT
void env_add_boot_state(unsigned int state)
{
    char newstr[40] = {0};
    sprintf(newstr, "androidboot.verifiedbootstate=%s", state == 0 ? "green" : state == 1 ? "yellow" : state == 2 ? "orange" : "red");
    env_add_bootargs("androidboot.verifiedbootstate=", newstr);
}
#endif

#ifdef CC_3RD_KO_INSERTION
#ifdef CC_EMMC_BOOT
extern int emmc_read_from_partition(unsigned char* buf, char* pname, u64 offset, unsigned int size);
#endif
static void env_add_beic_support(void)
{
	UINT32 u4ModelType=0;
	UINT32 u4EnableBe=0;
#ifdef CC_COMBINE_4K_2K
	EEPROM_Read((UINT64)0x10010, (UINT32)&u4ModelType, (UINT32)sizeof(char));
	EEPROM_Read((UINT64)0x1050A, (UINT32)&u4EnableBe, (UINT32)sizeof(char));

	if ((u4ModelType&0x08)==0)
	{
		goto out;
	}
	else if (u4EnableBe == 0x1)
	{
		goto out;
	}
#else
	EEPROM_Read((UINT64)BE_IC_SUPPORT_ADDR, (UINT32)&u4ModelType, (UINT32)sizeof(char));
	if(((UINT8)u4ModelType) != 0x79)
	{
		goto out;
	}
#endif

	//Printf("env_add_beic_support exist\n");
	env_add_bootargs("beic_supported=", "beic_supported=1");

out:
	return;
}


#endif


static void env_add_product_model(void)
{
	char newstr[32] = {0};
	char value = ((LDR_ENV_T *)CC_LDR_ENV_OFFSET)->szMSDCenv1[63];
	if(SUPPORT_SYS_POWER(POWER_SUPPORT_EMMC_SPEED))
	{
		value = 0x99;  //for MTK
	}
	sprintf(newstr, "product_model=%d", value);
	env_add_bootargs("product_model=", newstr);

	return ;
}

#ifdef CC_S_PLATFORM
static void env_add_from_mvi(void)
{
	char str[128+1] = {0};
	char str2[1] = {0};
	char newstr[64] = {0};
	UBOOT_EEPDTV_GetCustRawData((UINT32)str,0,(UINT32)(sizeof(str)-1)); //this api is safe
	if (str[0]) 
	{
		env_add_bootargs(str, str);
	}
	UBOOT_EEPDTV_GetCustRawData((UINT32)str2,128,1); //this api is safe
	if((str2[0]&0x3)==0x0)
	{
		char newstrtemp[16] ={"1920x1080"};
		sprintf(newstr, "androidboot.svp.panel.resolution=%s", newstrtemp);
		env_add_bootargs("androidboot.svp.panel.resolution=", newstr);
	}
	else
	{
		char newstrtemp[16] ={"3840x2160"};
		sprintf(newstr, "androidboot.svp.panel.resolution=%s", newstrtemp);
		env_add_bootargs("androidboot.svp.panel.resolution=", newstr);
	}
	return ;
}



#ifdef CC_DYNAMIC_USB_ADB_CONFIG
extern unsigned int UBOOT_EEPDTV_IsADB(void);
static void env_add_adb_support(void)
{
    char newstr[16] = {0};
    unsigned int u4Support=0;

    u4Support = UBOOT_EEPDTV_IsADB();

    Printf("+[env_add_adb_support] u4Support = %d", u4Support);

    if(u4Support)
    {
        sprintf(newstr, "adb_enable=%d", 1);
        env_add_bootargs("adb_enable=", newstr);
    }
	else
	{
        sprintf(newstr, "adb_enable=%d", 0);
        env_add_bootargs("adb_enable=", newstr);
	}
	sprintf(newstr, "adb_port=%d", 1);
    env_add_bootargs("adb_port=", newstr);
    
}
#endif
#ifdef CC_USB3_TO_ADB_PORT_CONFIG
extern unsigned int UBOOT_EEPDTV_IsU3ToADB(void);
static void env_add_u32adb_support(void)
{
    char newstr[16] = {0};
	unsigned int u4Support=0;
	char ddri_header[4] = {0};

    u4Support = UBOOT_EEPDTV_IsU3ToADB();
    Printf("env_add_u32adb_support read from EEPDTV u32adb ADB Support = %d\n", u4Support);

	if(u4Support)
	{
          sprintf(newstr, "u32adb=%d", 1);
          env_add_bootargs("u32adb=", newstr);
	}
	else
	{
          sprintf(newstr, "u32adb=%d", 0);
          env_add_bootargs("u32adb=", newstr);
	}
}
#endif
#else
#if 0
static void env_add_adb_support(void)
{
    char newstr[16] = {0};
    sprintf(newstr, "adb_enable=%d", 1);
    env_add_bootargs("adb_enable=", newstr);

    sprintf(newstr, "adb_port=%d", 0);
    env_add_bootargs("adb_port=", newstr);
}
#endif

#ifdef CC_WIFI_U2_SPEED_ON_U3PORT
static void env_add_wifi_u3_support(void)
{
	char newstr[16] = {0};
	sprintf(newstr, "wifi_u3=%d", 1);
	env_add_bootargs("wifi_u3=", newstr);
}
#endif
#ifdef CC_WIFI_25G_SUPPORT
static void env_add_wifi_25g_support(void)
{
	char newstr[16] = {0};
	sprintf(newstr, "wifi_25g=%d", 1);
	env_add_bootargs("wifi_25g=", newstr);
}
#endif

#ifdef CC_MTK_AUTO_TEST
static void env_add_adb_support(void)
{
	char newstr[16] = {0};
	sprintf(newstr, "adb_enable=%d", 1);		//default enable ADB AUTO_TEST mode.
	env_add_bootargs("adb_enable=", newstr);
}

#else
extern unsigned int UBOOT_EEPDTV_IsSupportADB(void);

#ifdef CC_UBOOT_CDC_ALWAYS_ENABLE
static void env_add_adb_support(void)
{
	char newstr[16] = {0};
	unsigned int u4Support=1;

    Printf("Env_common.c/env_add_adb_support for vfy ADB Support = %d\n", u4Support);

	if(u4Support)
	{
		sprintf(newstr, "adb_enable=%d", 1);
		env_add_bootargs("adb_enable=", newstr);
	}
}
#else
static void env_add_adb_support(void)
{
	char newstr[16] = {0};
	unsigned int u4Support=0;

    // get data from borad/mt5xxx/mt5xxx_sif.c
    // the detail layout confirm with corresponding SI
	u4Support = UBOOT_EEPDTV_IsSupportADB();
    Printf("Env_common.c/env_add_adb_support read EEPROM ADB Support = %d\n", u4Support);

	if(u4Support)
	{
		sprintf(newstr, "adb_enable=%d", 1);
		env_add_bootargs("adb_enable=", newstr);
	}
	else
		{
		sprintf(newstr, "adb_enable=%d", 0);
		env_add_bootargs("adb_enable=", newstr);
	}
}
#endif
#endif

#endif

#ifdef CC_UBOOT_TRANSFER_USBGPIO_KERNEL
#define MUSB_MAX_CONTROLLERS 4

static void env_add_usb_gpio(void)
{
	int i;
	int u4UsbPortConfig;
	char pstr[32];
	int _i4usbportusing[MUSB_MAX_CONTROLLERS] ={eUSB0Config,eUSB1Config,eUSB2Config,eUSB3Config};
	int _i4usbpwrgpio[MUSB_MAX_CONTROLLERS] ={eUSBVbus0Gpio,eUSBVbus1Gpio,eUSBVbus2Gpio,eUSBVbus3Gpio};
    #ifdef CC_USB_DELAY_RESUME_SUPPORT
	int _i4usbdelayresume[MUSB_MAX_CONTROLLERS] ={eUSB0DelayResume,eUSB1DelayResume,eUSB2DelayResume,eUSB3DelayResume};
    #endif
	int _i4usbpwrpolarity[MUSB_MAX_CONTROLLERS] ={eUSBVbus0EnablePolarity,eUSBVbus1EnablePolarity,eUSBVbus2EnablePolarity,eUSBVbus3EnablePolarity};
	int _i4usbocgpio[MUSB_MAX_CONTROLLERS] ={eUSB0OCGpio,eUSB1OCGpio,eUSB2OCGpio,eUSB3OCGpio};
	int _i4usbocgpiopolarity[MUSB_MAX_CONTROLLERS] ={eUSB0OCEnablePolarity,eUSB1OCEnablePolarity,eUSB2OCEnablePolarity,eUSB3OCEnablePolarity};

	char usbportusing[64] = "usbportusing=";
	char usbpwrgpio[64] = "usbpwrgpio=";
//	char usbpwrpolarity[32] = "usbpwrpolarity=";
    #ifdef CC_USB_DELAY_RESUME_SUPPORT
	char usbdelayresume[64] = "usbdelayresume=";
    #endif
	char usbocgpio[64] = "usbocgpio=";
//	char usbocgpiopolarity[32] = "usbocgpiopolarity=";
    char usbhubgpio[30] = "usbhubrstgpio=";

    for(i = 0; i < MUSB_MAX_CONTROLLERS; i++)
    	{
    		if(0 == DRVCUST_InitQuery(_i4usbportusing[i], &u4UsbPortConfig))
    			{
				sprintf(pstr,"%d",u4UsbPortConfig);
				strcat(usbportusing,pstr );
    		if( 0 ==DRVCUST_InitQuery(_i4usbpwrgpio[i], &u4UsbPortConfig))
    			{
					sprintf(pstr,"%d",u4UsbPortConfig);
					strcat(usbpwrgpio,pstr );
    			}
			else
				{
					strcat(usbpwrgpio,"-1");
				}
    			}
			else
				{
					strcat(usbpwrgpio,"-1");
					strcat(usbportusing,"-1");
				}
            #ifdef CC_USB_DELAY_RESUME_SUPPORT
			if( 0 == DRVCUST_InitQuery(_i4usbdelayresume[i], &u4UsbPortConfig))
			    {
				    sprintf(pstr,"%d",u4UsbPortConfig);
					strcat(usbdelayresume,pstr);
			    }
			else
			    {
					strcat(usbdelayresume,"-1");
			    }
            #endif
			if( 0==DRVCUST_InitQuery(_i4usbpwrpolarity[i], &u4UsbPortConfig))
				{
					sprintf(pstr,"%d",u4UsbPortConfig);
					strcat(usbpwrgpio,":");
					strcat(usbpwrgpio,pstr);
				}
			else
				{
					strcat(usbpwrgpio,":");
					strcat(usbpwrgpio,"-1");
				}

			if ( 0==DRVCUST_InitQuery(_i4usbocgpio[i], &u4UsbPortConfig))
				{
					sprintf(pstr,"%d",u4UsbPortConfig);
					strcat(usbocgpio,pstr);
				}
			else
				{
					strcat(usbocgpio,"-1");
				}

			if(0 ==DRVCUST_InitQuery(_i4usbocgpiopolarity[i], &u4UsbPortConfig))
				{
					sprintf(pstr,"%d",u4UsbPortConfig);
					strcat(usbocgpio,":");
					strcat(usbocgpio,pstr);
				}

			else
				{
					strcat(usbocgpio,":");
					strcat(usbocgpio,"-1");
				}
			if(i !=MUSB_MAX_CONTROLLERS-1)
				{

					strcat(usbportusing,",");
					strcat(usbpwrgpio,",");
                    #ifdef CC_USB_DELAY_RESUME_SUPPORT
                    strcat(usbdelayresume,",");
                    #endif
				//	strcat(usbpwrpolarity,",");
					strcat(usbocgpio,",");
				//	strcat(usbocgpiopolarity,",");

				}

    	}

        if(0 == DRVCUST_InitQuery(eUSBHubResetGpio, &u4UsbPortConfig))
        {
            sprintf(pstr,"%d",u4UsbPortConfig);
            strcat(usbhubgpio,pstr);
	    }
		else
		{
		    strcat(usbhubgpio,"-1");
		}

		if(0 == DRVCUST_InitQuery(eUSBHubResetPolarity, &u4UsbPortConfig))
        {
            sprintf(pstr,":%d",u4UsbPortConfig);
            strcat(usbhubgpio,pstr);
	    }
		else
		{
		    strcat(usbhubgpio,":-1");
		}
	//printf("%s,\n",	usbportusing);
	//printf("%s,\n",	usbpwrgpio);
	//printf("%s,\n",	usbpwrpolarity);
	//printf("%s,\n",	usbocgpio);
	//printf("%s,\n",	usbocgpiopolarity);

    env_add_bootargs("usbportusing=", usbportusing);
    env_add_bootargs("usbpwrgpio=", usbpwrgpio);
    #ifdef CC_USB_DELAY_RESUME_SUPPORT
	env_add_bootargs("usbdelayresume=", usbdelayresume);
    #endif
   // env_add_bootargs("usbpwrpolarity=", usbpwrpolarity);
    env_add_bootargs("usbocgpio=", usbocgpio);
  //  env_add_bootargs("usbocgpiopolarity=", usbocgpiopolarity);
    /* for cdc support, default support usb port0 */
    //env_add_bootargs("usbcdcsupport=", "usbcdcsupport=1,0,0,0");
    env_add_bootargs("usbhubrstgpio=", usbhubgpio);
}
#endif

#ifdef CC_UBOOT_TRANSFER_MSDCGPIO_KERNEL
#define MSDC_GPIO_MAX_NUMBERS 6

static void env_add_msdc_gpio(void)
{
	int i;
	int u4MsdcGpioConfig;
	char pstr[32];
	int _i4MSDCgpio[MSDC_GPIO_MAX_NUMBERS]={eMSDC0DetectGpio,eMSDC0WriteProtectGpio,eMSDC0PoweronoffDetectGpio,eMSDC0VoltageSwitchGpio,eMSDCbackup1Gpio,eMSDCbackup2Gpio};

	char msdcgpio[32] = "msdcgpio=";

    for(i = 0; i < MSDC_GPIO_MAX_NUMBERS; i++)
    {
		if( 0 ==DRVCUST_InitQuery(_i4MSDCgpio[i], &u4MsdcGpioConfig))
		{
			sprintf(pstr,"%d",u4MsdcGpioConfig);
			strcat(msdcgpio,pstr );
		}
		else
		{
			strcat(msdcgpio,"-1");
		}

		if(i !=MSDC_GPIO_MAX_NUMBERS-1)
		{
			strcat(msdcgpio,",");
		}
    }
	printf("%s,\n",msdcgpio);
    env_add_bootargs("msdcgpio=",msdcgpio);
}
#endif

static void env_add_wlan_gpio(void)
{
    int i4ResetWLangpio;
    char pstr[32];
    char rstwlan_gpio[32] = "rstwlan_gpio=";

    if (DRVCUST_InitQuery(eResetWLanGpio, &i4ResetWLangpio) == 0)
    {
        sprintf(pstr,"%d", i4ResetWLangpio);
        strcat(rstwlan_gpio, pstr);
    }
    else
    {
        strcat(rstwlan_gpio, "-1");
    }
    env_add_bootargs("rstwlan_gpio=", rstwlan_gpio);
}

#if CC_UBOOT_TRANSFER_MSDC_AUTOK_KERNEL
#define MSDC_AUTOK_NUMBERS 17
extern uint szAutoK_CmdLine[];

void env_add_msdc_autok(void)
{
	int i;
	int u4MsdcGpioConfig;
	char pstr[32];

	//printf("...=====MSDC Add Autok Param=====...\n");

	char autok[50+MSDC_AUTOK_NUMBERS*10] = "msdcautok=";

    for(i = 0; i < MSDC_AUTOK_NUMBERS; i++)
    {
        //printf("[%d] = 0x%x\n",i,szAutoK_CmdLine[i]);
		sprintf(pstr,"0x%x",szAutoK_CmdLine[i]);
		strcat(autok,pstr);

		if(i !=MSDC_AUTOK_NUMBERS-1)
		{
			strcat(autok,",");
		}
    }
	printf("\n %s \n",autok);
    env_add_bootargs("msdcautok=",autok);
}
#endif

#ifdef CC_TRUSTZONE_SUPPORT
static void env_add_tz_size(void)
{
    char *p;
    char buf[32];
    p = getenv("tzsize");
    sprintf(buf,"tzsz=%s", p);
    env_add_bootargs("tzsz=", buf);
}
#endif


#if defined(CC_CMDLINE_SUPPORT_BOOTREASON)
#define PDWNC_REG_RESERVE_BOOTREASON  ((volatile UINT32*)(IO_VIRT + 0x00028624))
static void env_add_bootreason(void)
{
    char newstr[64] = {0};
	UINT32 wakeupReason = (*(PDWNC_REG_RESERVE_BOOTREASON));
    //clear reboot reason register.
	(*(PDWNC_REG_RESERVE_BOOTREASON)) = wakeupReason & 0xFFFFFF00;

	if(( wakeupReason & 0xFF) == 0x1)
	{
		sprintf(newstr, "androidboot.bootreason=kernel_panic");
	}
	else if(( wakeupReason & 0xFF) == 0x2)
	{
		sprintf(newstr, "androidboot.bootreason=reboot");
	}
	else if(( wakeupReason & 0xFF) == 0x3)
	{
		sprintf(newstr, "androidboot.bootreason=watchdog");
	}
	else
	{
	    //normal boot.
		return;
	}
	env_add_bootargs("androidboot.bootreason=", newstr);
}
#endif

#ifdef ANDROID
#ifdef CC_UBOOT_MINIGUNZIP_SUPPORT
static void env_add_minigzip(void)
{
    char newstr[32] = {0};

    sprintf(newstr, "minigzip=1");
    env_add_bootargs("minigzip=", newstr);
}
#endif
#endif
#ifdef CC_SUPPORT_STR
static void env_add_no_console_suspend(void)
{
    char newstr[32] = {0};

    sprintf(newstr, "no_console_suspend");
    env_add_bootargs("no_console_suspend", newstr);
}
#endif
#ifdef CC_ENABLE_CMA_SUPPORT
static void env_add_cma(void)
{
    char newstr[32] = {0};

    sprintf(newstr, "cma=0");
    env_add_bootargs("cma=", newstr);
}
#endif
#ifdef CC_PDWNC_REBOOT_NOTIFY
static void env_add_recovery_mode(void)
{
    char newstr[32] = {0};

    if (BIM_IsRecoveryMode())
    {
        sprintf(newstr, "AndroidRecovery");
        env_add_bootargs("AndroidRecovery", newstr);
    }
}
#endif

#ifdef CC_CUSTOM_PMIC_I2C_SUPPORT
#define MTK_PMIC_I2C_NUMS 20
void env_add_pmic_i2c(void)
{
	int i;
	int u4PMICConfig;
	char pstr[32];
	int _i4pmicusing[MTK_PMIC_I2C_NUMS] =
	{
	eGetVCPUdevaddr,
	eGetVCPUdataddr,
	eGetVCPUmodaddr,
	eGetVCPUmodmask,
	eGetVCPUmodepwm_en,
	eGetVCPUvmin,
	eGetVCPUvmax,
	eGetVCPUvstep,
	eGetVCPUchannelid,
	eGetVCPUpmicEN,
	eGetVGPUdevaddr,
	eGetVGPUdataddr,
	eGetVGPUmodaddr,
	eGetVGPUmodmask,
	eGetVGPUmodepwm_en,
	eGetVGPUvmin,
	eGetVGPUvmax,
	eGetVGPUvstep,
	eGetVGPUchannelid,
	eGetVGPUpmicEN};

	printf("...=====PMIC I2C Param=====...\n");

	char mtk_regulator[50+MTK_PMIC_I2C_NUMS*4] = "mt53xxregulator=";

	for(i=0;i<MTK_PMIC_I2C_NUMS;i++)
	{
		if(0 == DRVCUST_InitQuery(_i4pmicusing[i], &u4PMICConfig))
		{
			sprintf(pstr,"%d",u4PMICConfig);
			strcat(mtk_regulator,pstr );
		}
		else
		{
			strcat(mtk_regulator,"-1");
		}
		strcat(mtk_regulator,":");
	}

	printf("\n %s \n",mtk_regulator);
    env_add_bootargs("mt53xxregulator=",mtk_regulator);
}
#endif

extern int DRVCUST_QueryPart(int i, int *pData, int type);
extern int DRVCUST_QueryPart64(int i, u64 *pData, int type);

/* Build cmdline partition table
 * For detail please refer to kernel document:
 * Documentation/block/cmdline-partition.txt
 */
static void set_cmdline_env(void)
{
#define SZ1M	0x100000U
#ifndef CC_KERNEL_ON_NOR
	int i = 0, parts, encrypt = 0;
#ifdef CC_PARTITION_WP_SUPPORT
	int wp = 0;
#endif
	u64 size = 0;
	char *p1 = NULL, *p2 = NULL;
	char buf[64] = {0};
	char *name = NULL;
	/* Commandline */
	char *cmdline = NULL;
	char *enc = NULL;
	char *bootargs = NULL;

	cmdline = (char *)malloc(default_environment_size);
	memset(cmdline, 0, default_environment_size);

	enc = (char *)malloc(default_environment_size);
	memset(enc, 0, default_environment_size);

	bootargs = (char *)malloc(default_environment_size);
	memset(bootargs, 0, default_environment_size);

	DRVCUST_QueryPart(0, &parts, 0);

	while (i <= parts) {
		DRVCUST_QueryPart64(i, &size, 1);
		DRVCUST_QueryPart(i, (UPTR *)&name, 2);
		DRVCUST_QueryPart(i, &encrypt, 3);
#ifdef CC_PARTITION_WP_SUPPORT
		DRVCUST_QueryPart(i, &wp, 4);
#endif
		if (!size)
			break;

		if (size & (SZ1M - 1))
			sprintf(buf, "%llu(%s),", size, name);
		else
			sprintf(buf, "%um(%s),", (u32)(size / SZ1M), name);

		strcat(cmdline, buf);

		if (encrypt) {
			char ch[4] = {'\0'};
			sprintf(ch, "%d", i);
			strcat(enc, ch);
			if (i != parts - 1)
				strcat(enc, ",");
		}

		i++;
	}

	enc[strlen(enc) - 1] = '\0';
	cmdline[strlen(cmdline) - 1] = '\0';

	strcpy(mtdparts_default, cmdline);

	// update cmdline string
	setenv("blkdevparts", cmdline);
	setenv("blkdevpartenc", enc);

	// generate bootargs string
	p1 = getenv("bootargs");
	if (p1 == NULL) {
		free(bootargs);
		free(enc);
		free(cmdline);
		return;
	}

	strcpy(bootargs, p1);

	// delete any existing cmdline string in bootargs string.
	p1 = strstr(bootargs, "blkdevparts=");
	if (p1) {
		p2 = strstr(p1, " ");
		if(p2) {
			while(*++p2)
				*p1++ = *p2;

			*p1++ = ' ';
		}

		*p1 = '\0';
	} else {
		strcat(bootargs, " ");
	}

	// append new cmdline string at the end of bootargs string.
	strcat(bootargs, "blkdevparts=mmcblk0:");
	strcat(bootargs, cmdline);

	// delete any existing encryption string in bootargs string.
	p1 = strstr(bootargs, "blkdevpartenc=");
	if (p1) {
		p2 = strstr(p1, " ");
		if(p2) {
			while(*++p2)
				*p1++ = *p2;

			*p1++ = ' ';
		}

		*p1 = '\0';
	} else {
		strcat(bootargs, " ");
	}

	// append new cmdline string at the end of bootargs string.
	strcat(bootargs, "blkdevpartenc=");
	strcat(bootargs, enc);

	// update bootargs environment
	setenv("bootargs", bootargs);
	free(cmdline);
	free(bootargs);
#endif
}

/* set_cmdline_env() build the partition table and
 * store it in bootargs, but we still need set_part_env()
 * to build mtdparts for uboot internal use
 */
static void set_part_env(void)
{
#ifndef CC_KERNEL_ON_NOR
	int i = 0, i4PartNum = 0, encrypt = 0;
	u64 size = 0;
	char *p1 = NULL, *p2 = NULL;
	char *name = NULL;
	char buf[64] = {0};
	char *mtdparts = NULL;
#ifdef CC_PARTITION_WP_SUPPORT
	int wp = 0;
#endif

	mtdparts = (char *)malloc(default_environment_size);
	memset(mtdparts, 0, default_environment_size);

	DRVCUST_QueryPart(0, &i4PartNum, 0);

	// generate mtdparts string
	while (i <= i4PartNum) {
		DRVCUST_QueryPart64(i, &size, 1);
		DRVCUST_QueryPart(i, (UPTR *)&name, 2);
		DRVCUST_QueryPart(i, &encrypt, 3);
#ifdef CC_PARTITION_WP_SUPPORT
		DRVCUST_QueryPart(i, &wp, 4);
#endif
		if (!size)
			break;

		if (i == 0) {
#if defined(CC_EMMC_BOOT)
			strcat(mtdparts, "mt53xx-emmc:");
#else
			strcat(mtdparts, "mt53xx-nand:");
#endif
		} else
			strcat(mtdparts, ",");

		/* CAUTION: 64 bit size limition 2TB !!! */
		if ((size % (1024 * 1024)) == 0)
			sprintf(buf, "%dM(%s)", (u32)(size /1024 /1024), name);
		else if ((size % 1024) == 0)
			sprintf(buf, "%dk(%s)", (u32)(size /1024), name);
		else
			BUG();

		strcat(mtdparts, buf);

		if (encrypt)
			strcat(mtdparts, "enc");
#ifdef CC_PARTITION_WP_SUPPORT
		if (wp)
			strcat(mtdparts, "wp");
#endif

		i++;
	}

	strcpy(mtdparts_default, mtdparts);

	// update mtdparts string
	setenv("mtdparts", mtdparts);

	free(mtdparts);
#endif
}

static void set_cust_env(void)
{
    char buf[64] = {0};

	set_cmdline_env();
	set_part_env();

    // set kernel memory size, kmemsize always is not equal to zero.
    if (kmemsize)
    {
        sprintf(buf, "0x%x", kmemsize);
        setenv("kmemsize", buf);
#ifdef CC_FBM_DYNMJC
        sprintf(buf, "0x%x", kmemsize_nomjc);
        setenv("kmemsize_nomjc", buf);
#endif
#ifdef CC_TWO_MEM_REGION_BANK
        sprintf(buf, "0x%x%08x", kmemstart2_high,kmemstart2_low);
        setenv("kmemstart2", buf);
        sprintf(buf, "0x%x", kmemsize2);
        setenv("kmemsize2", buf);
		sprintf(buf, "0x%x", kmemsize2_4G);
        setenv("kmemsize2_4G", buf);
		sprintf(buf, "0x%x", kmemsize2_3_5G);
        setenv("kmemsize2_3_5G", buf);
		sprintf(buf, "0x%x", kmemsize2_3G);
        setenv("kmemsize2_3G", buf);
#endif
#if defined(CC_DYNAMIC_FBMSRM_CONF)
		sprintf(buf, "0x%x", kmem4ksize);
		setenv("kmem4ksize", buf);
		sprintf(buf, "0x%x", kmemfhdsize);
		setenv("kmemfhdsize", buf);
#endif
#if CONFIG_NR_DRAM_BANKS>1
        sprintf(buf, "0x%x", kmem2start);
        setenv("kmem2start", buf);
        sprintf(buf, "0x%x", kmem2size);
        setenv("kmem2size", buf);
#if defined(CC_DYNAMIC_FBMSRM_CONF)
        sprintf(buf, "0x%x", kmem24ksize);
        setenv("kmem24ksize", buf);
        sprintf(buf, "0x%x", kmem2fhdsize);
        setenv("kmem2fhdsize", buf);
        sprintf(buf, "%d", gpu4kstart);
        setenv("gpu4kstart", buf);
        sprintf(buf, "%d", gpufhdstart);
        setenv("gpufhdstart", buf);
        sprintf(buf, "%d", gpu4ksize);
        setenv("gpu4ksize", buf);
        sprintf(buf, "%d", gpufhdsize);
        setenv("gpufhdsize", buf);
        sprintf(buf, "%d", gpu4kionsize);
        setenv("gpu4kionsize", buf);
        sprintf(buf, "%d", gpufhdionsize);
        setenv("gpufhdionsize", buf);
#endif
#endif
#ifdef CC_SUPPORT_CHANNEL_C
	sprintf(buf, "0x%x", kmem3start);
	setenv("kmem3start", buf);
	sprintf(buf, "0x%x", kmem3size);
	setenv("kmem3size", buf);
#endif

    }
	
#ifdef CC_RAMOOPS_SUPPORT
	//RamoopsMemAddress always is not equal to zero.
	if (RamoopsMemAddress)
	{
		sprintf(buf, "0x%x", RamoopsMemAddress);
		setenv("ramoops.mem_address", buf);

		sprintf(buf,"0x%x",RAMOOP_MEM_SIZE);
		setenv("ramoops.mem_size", buf);
		
		sprintf(buf,"0x%x",RAMOOP_CONSOLE_SIZE);
		setenv("ramoops.console_size", buf);
		
		sprintf(buf,"0x%x",RAMOOP_FTRACE_SIZE);
		setenv("ramoops.ftrace_size", buf);
		
		sprintf(buf,"0x%x",RAMOOP_PMSG_SIZE);
		setenv("ramoops.pmsg_size", buf);
		
		sprintf(buf,"0x%x",RAMOOP_RECORD_SIZE);
		setenv("ramoops.record_size", buf);
	}
#endif

#ifdef CC_TRUSTZONE_SUPPORT
    if(TRUSTZONE_MEM_SIZE%(1024*1024) == 0)
    {
        sprintf(buf,"%dm", TRUSTZONE_MEM_SIZE/(1024*1024));
    }
    else if(TRUSTZONE_MEM_SIZE%1024 == 0)
    {
        sprintf(buf,"%dk", TRUSTZONE_MEM_SIZE/(1024));
    }
    else
    {
        sprintf(buf, "%d", TRUSTZONE_MEM_SIZE);
    }
    setenv("tzsize", buf);
#endif

#ifdef CC_ANDROID_SECURE_BOOT_CLASS_B
#ifdef CC_ANDROID_SECURE_BOOT_UNLOCK
    setenv("devicestate", "unlock");
#else
    setenv("devicestate", "lock");
#endif
#endif//CC_ANDROID_SECURE_BOOT_CLASS_B
}

void set_default_env(const char *s)
{
    unsigned int* penv;
	if (sizeof(default_environment) > ENV_SIZE) {
		puts("\n*** Error - default environment is too large.\n\n");
		return;
	}

	if (s) {
		if (*s == '!') {
			printf("\n*** Warning - %s, using default environment.\n\n", s+1);
		} else {
			puts(s);
		}
	} else {
		puts("\nUsing default environment.\n\n");
	}
	
	penv = (unsigned int*)env_ptr;
	//get ATAG kernel memory from env.o
	if (penv[0]==0x464c457f)
	{
		int i=1;
		for (; i<0x40; i++)
		{
			// find magic key, the next work is global_kernel_dram_size
			if (penv[i] == 0x53965368)
			{
		#if defined(CC_DYNAMIC_FBMSRM_CONF)
				kmemsize = penv[i+1];
				kmem4ksize = penv[i+2];
				kmemfhdsize = penv[i+3];

			#if CONFIG_NR_DRAM_BANKS>1
				kmem2start = penv[i+4];
				kmem2size = penv[i+5];
				kmem24ksize = penv[i+6];
				kmem2fhdsize = penv[i+7];
			#endif
				gpu4kstart = penv[i+8];
				gpufhdstart = penv[i+9];
				gpu4ksize = penv[i+10];
				gpufhdsize = penv[i+11];
				gpu4kionsize = penv[i+12];
				gpufhdionsize = penv[i+13];
			#ifdef CC_SUPPORT_CHANNEL_C
				kmem3start = penv[i+14];
				kmem3size = penv[i+15];
			#endif
			#ifdef CC_RAMOOPS_SUPPORT
				RamoopsMemAddress = penv[i+16];
			#endif
		#else
				kmemsize = penv[i+1];
			#if CONFIG_NR_DRAM_BANKS>1
				kmem2start = penv[i+2];
				kmem2size = penv[i+3];

				#ifdef CC_SUPPORT_CHANNEL_C
				kmem3start = penv[i+4];
				kmem3size = penv[i+5];
				#endif

				#ifdef CC_RAMOOPS_SUPPORT
					#ifndef CC_SUPPORT_CHANNEL_C 
				RamoopsMemAddress = penv[i+4];
					#else
				RamoopsMemAddress = penv[i+6];
					#endif
				#endif
			#else
				#ifdef CC_TWO_MEM_REGION_BANK
				kmemstart2_high = penv[i+2];
				kmemstart2_low = penv[i+3];
				kmemsize2 = penv[i+4];
				kmemsize2_4G = penv[i+5];
				kmemsize2_3_5G = penv[i+6];
				kmemsize2_3G = penv[i+7];
				#ifdef CC_FBM_DYNMJC
				kmemsize_nomjc = penv[i+8];
				#endif
				#else
				#ifdef CC_FBM_DYNMJC
				kmemsize_nomjc = penv[i+2];
				#endif
				#endif

				#ifdef CC_RAMOOPS_SUPPORT
				#ifdef CC_TWO_MEM_REGION_BANK
				#ifdef CC_FBM_DYNMJC
				RamoopsMemAddress = penv[i+9];
				#else
				RamoopsMemAddress = penv[i+8];
				#endif
				#else
				#ifdef CC_FBM_DYNMJC
				RamoopsMemAddress = penv[i+3];
				#else
				RamoopsMemAddress = penv[i+2];
				#endif
				#endif
				#endif
			#endif
		#endif
				printf("set_default_env from env partition !!!\n\n kmemsize\t= 0x%08x\n kmemstart2\t= 0x%x%08x\n kmemsize2\t= 0x%08x\n kmem2start\t= 0x%08x\n kmem2size\t= 0x%08x\n kmem3start\t= 0x%08x\n kmem3size\t= 0x%08x\n\n", kmemsize, kmemstart2_high, kmemstart2_low, kmemsize2, kmem2start, kmem2size,kmem3start,kmem3size);
				break;
			}
		}
	}

	//if get ATAG kernel memory from env.o fail, force initial
	if(kmemsize == 0)
	{
		kmemsize = PHYS_SDRAM_1_SIZE;
#ifdef CC_FBM_DYNMJC
		kmemsize_nomjc = PHYS_SDRAM_1_SIZE_NOMJC;
#endif
#ifdef CC_TWO_MEM_REGION_BANK
        kmemstart2_high = (PHYS_SDRAM_1_2 >> 32);
        kmemstart2_low = (PHYS_SDRAM_1_2 & 0xffffffff);
        kmemsize2 = PHYS_SDRAM_1_2_SIZE;
		kmemsize2_4G = PHYS_SDRAM_1_2_SIZE_4G;
		kmemsize2_3_5G = PHYS_SDRAM_1_2_SIZE_3_5G;
		kmemsize2_3G = PHYS_SDRAM_1_2_SIZE_3G;
#endif
#if defined(CC_DYNAMIC_FBMSRM_CONF)
		kmem4ksize = PHYS_SDRAM_1_4K_SIZE;
		kmemfhdsize = PHYS_SDRAM_1_FHD_SIZE;

	#if CONFIG_NR_DRAM_BANKS>1
		kmem2start = PHYS_SDRAM_2;
		kmem2size = PHYS_SDRAM_2_SIZE;
		kmem24ksize = PHYS_SDRAM_2_4K_SIZE;
		kmem2fhdsize = PHYS_SDRAM_2_FHD_SIZE;
	#endif
	#if defined(PHYS_GPU_4K_START)&&defined(PHYS_GPU_FHD_START)
		gpu4kstart = PHYS_GPU_4K_START;
		gpufhdstart = PHYS_GPU_FHD_START;
		gpu4ksize = PHYS_GPU_4K_SIZE;
		gpufhdsize = PHYS_GPU_FHD_SIZE;
		gpu4kionsize = PHYS_GPU_4K_ION_SIZE;
		gpufhdionsize = PHYS_GPU_FHD_ION_SIZE;
	#endif
#else
	#if CONFIG_NR_DRAM_BANKS>1
		kmem2start = PHYS_SDRAM_2;
		kmem2size = PHYS_SDRAM_2_SIZE;

		#ifdef CC_SUPPORT_CHANNEL_C
		kmem3start = PHYS_SDRAM_3;
		kmem3size = PHYS_SDRAM_3_SIZE;
		#endif
	#endif
#endif
	#ifdef CC_RAMOOPS_SUPPORT
		RamoopsMemAddress = RAMOOP_MEM_ADDRESS;
	#endif

		printf("set_default_env from macro definition !!!\n\n kmemsize\t= 0x%08x\n kmemstart2\t= 0x%x%08x\n kmemsize2\t= 0x%08x\n kmem2start\t= 0x%08x\n kmem2size\t= 0x%08x\n kmem3start\t= 0x%08x\n kmem3size\t= 0x%08x\n\n", kmemsize, kmemstart2_high, kmemstart2_low, kmemsize2, kmem2start, kmem2size,kmem3start,kmem3size);
	}

	if (himport_r(&env_htab, (char *)default_environment,
			sizeof(default_environment), '\0', 0) == 0)
		error("Environment import failed: errno = %d\n", errno);

	gd->flags |= GD_FLG_ENV_READY;

	set_cust_env();
    saveenv();
}

/*
 * Check if CRC is valid and (if yes) import the environment.
 * Note that "buf" may or may not be aligned.
 */
int env_import(const char *buf, int check)
{
	env_t *ep = (env_t *)buf;

	if (check) {
		uint32_t crc;

		memcpy(&crc, &ep->crc, sizeof(crc));

		if (crc32(0, ep->data, ENV_SIZE) != crc) {
			set_default_env("!bad CRC");
			return 0;
		}
	}

	if (himport_r(&env_htab, (char *)ep->data, ENV_SIZE, '\0', 0)) {
		gd->flags |= GD_FLG_ENV_READY;
		return 1;
	}

	error("Cannot import environment: errno = %d\n", errno);

	set_default_env("!import failed");

	return 0;
}
#if defined(CC_SECURE_ROM_BOOT)
int IsRunOnUsb(char* uenv, int uenv_size);

static void env_add_usig(void)
{
    char *p1 = NULL;
    char uenv[125];

    if (IsRunOnUsb((char *)&uenv, sizeof(uenv)))
    {
        // generate bootargs string
        p1 = getenv("bootargs");
        if (p1 == NULL)
        {
            return;
        }
        printf("run_on_usb, uenv=%s\n", uenv);
        // append new string at the end of bootargs string.
        strcat(p1, " ");
        strcat(p1, uenv);
        // update bootargs environment
        setenv("bootargs", p1);
        setenv("usigenv", uenv);
    }

}
#endif // CC_SECURE_ROM_BOOT

#if defined(CC_RAMOOPS_SUPPORT)

static void env_add_ramoop(void)
{
	char newstr[64] = {0};

	sprintf(newstr, "ramoops.mem_address=%s", getenv("ramoops.mem_address"));
	env_add_bootargs("ramoops.mem_address=", newstr);

	sprintf(newstr,"ramoops.mem_size=%s",getenv("ramoops.mem_size"));
	env_add_bootargs("ramoops.mem_size=", newstr);

	sprintf(newstr,"ramoops.console_size=%s",getenv("ramoops.console_size"));
	env_add_bootargs("ramoops.console_size=", newstr);

	sprintf(newstr,"ramoops.ftrace_size=%s",getenv("ramoops.ftrace_size"));
	env_add_bootargs("ramoops.ftrace_size=", newstr);

	sprintf(newstr,"ramoops.pmsg_size=%s",getenv("ramoops.pmsg_size"));
	env_add_bootargs("ramoops.pmsg_size=", newstr);

	sprintf(newstr,"ramoops.record_size=%s",getenv("ramoops.record_size"));
	env_add_bootargs("ramoops.record_size=", newstr);
}

#endif // CC_SECURE_ROM_BOOT

#if defined(ANDROID) && defined(CC_SUPPORT_DTO) && defined(CC_SUPPORT_VERIFY_DTBO_BY_VTS)
void env_add_boot_dtbo_index(char* index_string)
{
    const char boot_dtbo_prefix[] = "androidboot.dtbo_idx=";
    char boot_dtbo_args[64] = {0};

    strcpy(boot_dtbo_args,boot_dtbo_prefix);
    strcat(boot_dtbo_args,index_string);
    env_add_bootargs(boot_dtbo_prefix, boot_dtbo_args);
}
#endif

#ifdef CC_SUPPORT_AB_UPDATE
void env_add_boot_slot_suffix(char* slot_suffix)
{
    const char boot_slot_prefix[] = "androidboot.slot_suffix=";
    char boot_slot_args[64] = {0};

    strcpy(boot_slot_args,boot_slot_prefix);
    strcat(boot_slot_args,slot_suffix);
    env_add_bootargs(boot_slot_prefix, boot_slot_args);
}

void env_add_boot_skip_initramfs(void)
{
    const char boot_skip_initramfs[] = "skip_initramfs";
    env_add_bootargs(boot_skip_initramfs, boot_skip_initramfs);
}
#endif

#ifdef CC_SUPPORT_AVB
void env_add_boot_avb_cmdline(char* avb_cmdline)
{
    printf("\n## AVB2.0 append extra bootargs:\n%s\n\n",avb_cmdline);
    env_add_bootargs(NULL, avb_cmdline);
}
#endif

#ifdef CC_LOADER_LOGO_LONG_TIME
void env_add_loaderlogo()
{
    unsigned long base,size;
    char buf[32];
    base = ((LDR_ENV_T *)CC_LDR_ENV_OFFSET)->u4LoaderLogoAddr;
    size = ((LDR_ENV_T *)CC_LDR_ENV_OFFSET)->u4LoaderLogoSize;
    Printf("loaderlogo=0x%x@0x%x\n", size, base);
    sprintf(buf,"loaderlogo=0x%x@0x%x", size, base);
    env_add_bootargs("loaderlogo=", buf);
}
#endif
static void env_add_coherent(void)//limit coherent_pool to 1*PAGE_SIZE assume that nobody will allocate dma memory in atomic context
{
#ifndef CC_SUPPORT_WIFI//wifi driver need to do usb_alloc_coherent in atomic context
    char newstr[32] = {0};

    sprintf(newstr, "coherent_pool=%s", "0x1000");
    env_add_bootargs("coherent_pool=", newstr);
#endif    
}
void env_relocate(void)
{
#ifdef CC_FBM_DYNMJC
    int is_support_mjc60 = ((LDR_ENV_T *)CC_LDR_ENV_OFFSET)->u4SupportMJC60;
#endif
#if defined(CONFIG_NEEDS_MANUAL_RELOC)
    env_reloc();
#endif

    if (gd->env_valid == 0) {
#if defined(CONFIG_ENV_IS_NOWHERE) /* Environment not changable */
        set_default_env(NULL);
#else
        show_boot_progress(-60);
        set_default_env("!bad CRC");
#endif
    } else {
        env_relocate_spec();
#ifndef CC_KERNEL_ON_NOR
        {
            char *p1 = NULL;

            p1 = getenv("mtdparts");
            if (p1 == NULL)
            {
                return;
            }
            strcpy(mtdparts_default, p1);
        }
#endif
    }

#ifdef CC_ENABLE_MTK_MODEL_INDEX
    env_add_panel_index();
#endif

#ifdef CC_ENABLE_MALI_CORE_NUM
    env_add_mali_core_num();
#endif

#ifdef CC_UBOOT_TRANSFER_USBGPIO_KERNEL
    env_add_usb_gpio();
#endif

#ifdef CC_S_PLATFORM
#ifdef CC_UBOOT_TRANSFER_UART_MODE
    env_add_uart_mode();
#endif
#endif

#ifdef CC_UBOOT_TRANSFER_MSDCGPIO_KERNEL
    env_add_msdc_gpio();
#endif

#ifdef CC_TRUSTZONE_SUPPORT
    env_add_tz_size();
#endif

#ifdef CC_FAST_INIT
    env_add_fastboot();
#endif

#ifdef CC_SUPPORT_STR
    env_add_no_console_suspend();
#endif

#ifdef CC_ENABLE_CMA_SUPPORT
    env_add_cma();
#endif

#ifdef ANDROID
#ifdef CC_UBOOT_MINIGUNZIP_SUPPORT
    env_add_minigzip();
#endif
#endif

#ifdef CC_PDWNC_REBOOT_NOTIFY
    env_add_recovery_mode();
#endif

#ifdef CC_MT53XX_SUPPORT_2G_DRAM
    //env_add_vmalloc_cust();
#endif

#ifdef CC_SECURE_ROM_BOOT
    env_add_usig();
#endif

#ifdef CONFIG_AMIGAONEG3SE
    disable_nvram();
#endif

#ifdef CC_KERNEL_NO_LOG
    env_add_forbid_uart();
#endif

    env_add_uart_perfor();

#ifdef CC_ENABLE_CMA_SUPPORT
char*	cmaCHA = getenv("cma_support_Cha");
if(cmaCHA == NULL)
{
	setenv("cma_support_Cha", "Y");
	cmaCHA = getenv("cma_support_Cha");
}
if(!strcmp(cmaCHA, "Y"))
{
  env_add_cmaCHA_startaddress();
  env_add_cmaCHA_size();
}
else
{
  env_del_cmaCHA_startaddress();
  env_del_cmaCHA_size();
}

#if CONFIG_NR_DRAM_BANKS>1
char*	cmaCHB = getenv("cma_support_Chb");
if(cmaCHB == NULL)
{
	setenv("cma_support_Chb", "Y");
	cmaCHB = getenv("cma_support_Chb");
}
if(!strcmp(cmaCHB, "Y"))
{
  env_add_cmaCHB_startaddress();
  env_add_cmaCHB_size();
}
else
{
  env_del_cmaCHB_startaddress();
  env_del_cmaCHB_size();
}
#endif

#if defined(CC_SUPPORT_CHANNEL_C)
char*	cmaCHC = getenv("cma_support_Chc");
if(cmaCHC == NULL)
{
	setenv("cma_support_Chc", "Y");
	cmaCHC = getenv("cma_support_Chc");
}
if(!strcmp(cmaCHC, "Y"))
{
  env_add_cmaCHC_startaddress();
  env_add_cmaCHC_size();
}
else
{
  env_del_cmaCHC_startaddress();
  env_del_cmaCHC_size();
}
#endif
#endif

#ifdef CC_VP9_SUPPORT
    env_add_vp9_support();
#endif

    env_add_gpu_addr();
    env_add_usb_serialno();

#ifdef CC_3RD_KO_INSERTION
    env_add_beic_support();
#endif

    env_add_product_model();
#ifdef CC_S_PLATFORM
    if (IS_IC_5893())
    {
        env_add_from_mvi();
    }
#ifdef CC_DYNAMIC_USB_ADB_CONFIG
    env_add_adb_support();
#endif
#ifdef CC_USB3_TO_ADB_PORT_CONFIG
    env_add_u32adb_support();
#endif
#else
    env_add_adb_support();
#endif // CC_S_PLATFORM

#ifdef CC_SUPPORT_CHIPID
#if defined(ANDROID) || defined(CC_C4TV_SUPPORT)
    env_add_chipid();
#endif
#endif

#if defined(CC_CMDLINE_SUPPORT_BOOTREASON)
    env_add_bootreason();
#endif
#ifdef CC_CMDLINE_UPGRADE_STATUS
    if (((LDR_ENV_T *)CC_LDR_ENV_OFFSET)->u4UpgradeStatus == 1)
    {
        env_add_bootargs("upgrade_bit=", "upgrade_bit=1");
    }
#endif

#ifdef LPJ_IC_VER1
    if (BSP_GetIcVersion() == LPJ_IC_VER1)
    {
        env_add_bootargs("lpj=", LPJ_IC_VALUE1);
    }
#endif

#ifdef LPJ_IC_VER1
    if (BSP_GetIcVersion() == LPJ_IC_VER2)
    {
        env_add_bootargs("lpj=", LPJ_IC_VALUE2);
    }
#endif

#if defined(CC_UBOOT_ADD_USB_LOG_MODE)
    env_add_usb_log();
#endif

#ifdef CC_UBOOT_ADD_USB_ETH_MODE
    env_add_usb_eth();
#endif

#if CC_UBOOT_TRANSFER_MSDC_AUTOK_KERNEL
    env_add_msdc_autok();
#endif

#ifndef CC_UBOOT_WO_AUTOSTART
    setenv("autostart", "yes");
#endif

#ifdef CC_WIFI_25G_SUPPORT
    env_add_wifi_25g_support();
#endif

#ifdef SYS_C4TV_SUPPORT
    env_add_dual_partition();
#endif

#if defined(CC_RAMOOPS_SUPPORT)
    env_add_ramoop();
#endif

#ifdef CC_LOADER_LOGO_LONG_TIME
    env_add_loaderlogo();
#endif

#if defined(CC_CUSTOM_PMIC_I2C_SUPPORT)
    env_add_pmic_i2c();
#endif
    env_add_wlan_gpio();
    env_add_coherent();
    {
        char str[64];
        #if defined(CC_FBM_FB_IN_CHANNELB) // fb buffer in fbm pool
            #if defined(CC_UBOOT_TWO_BANK)
                sprintf(str,"fb_start=0x%x", TOTAL_MEM_SIZE + PHYS_SDRAM_2_SIZE); // multi-channel,fb buffer in channelB
            #else
                #ifdef CC_TWO_MEM_REGION_BANK  // for husky two region case!
                    sprintf(str,"fb_start=0x%x", PHYS_SDRAM_1 + PHYS_SDRAM_1_SIZE + DIRECT_FB_MEM_SIZE);
                #else  //for one channel case!
                    sprintf(str,"fb_start=0x%x", TOTAL_MEM_SIZE - FBM_MEM_CFG_SIZE - TRUSTZONE_MEM_SIZE);
                #endif
            #endif
        #else
            #ifndef CC_FBM_DYNMJC
            sprintf(str,"fb_start=0x%x", PHYS_SDRAM_1 + PHYS_SDRAM_1_SIZE);
            #else
            if(IS_IC_5887()&&(!is_support_mjc60))
            {
                sprintf(str,"fb_start=0x%x", PHYS_SDRAM_1 + PHYS_SDRAM_1_SIZE_NOMJC);
            }
            else
            {
                sprintf(str,"fb_start=0x%x", PHYS_SDRAM_1 + PHYS_SDRAM_1_SIZE);
            }
            #endif
        #endif
        env_add_bootargs("fb_start=", str);
        #if defined(CC_FBM_FB_IN_CHANNELB)
        sprintf(str,"fb_size=0x%x", FBM_MTFB_SIZE/2);
        #else
        sprintf(str,"fb_size=0x%x", FB_MEM_SIZE/2);
        #endif
        env_add_bootargs("fb_size=", str);
    }
}

#ifdef CONFIG_AUTO_COMPLETE
int env_complete(char *var, int maxv, char *cmdv[], int bufsz, char *buf)
{
	ENTRY *match;
	int found, idx;

	idx = 0;
	found = 0;
	cmdv[0] = NULL;

	while ((idx = hmatch_r(var, idx, &match, &env_htab))) {
		int vallen = strlen(match->key) + 1;

		if (found >= maxv - 2 || bufsz < vallen)
			break;

		cmdv[found++] = buf;
		memcpy(buf, match->key, vallen);
		buf += vallen;
		bufsz -= vallen;
	}

	qsort(cmdv, found, sizeof(cmdv[0]), strcmp_compar);

	if (idx)
		cmdv[found++] = "...";

	cmdv[found] = NULL;
	return found;
}
#endif
