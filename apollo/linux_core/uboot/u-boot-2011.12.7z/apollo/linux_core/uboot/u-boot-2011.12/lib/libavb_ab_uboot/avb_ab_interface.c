
#include <common.h>

#include "avb_ab_interface.h"
#include "avb_ops_uboot.h"
#include "../libavb_ab/libavb_ab.h"
#include "../../../board/mt53xx_com/mt53xx_com_rpmb.h"

static const char* slot_suffixes[2] = {"_a", "_b"};

static bool slot_is_bootable(AvbABSlotData* slot) {
  return slot->priority > 0 &&
         (slot->successful_boot || (slot->tries_remaining > 0));
}

int ab_getCurrentSlotIndex(void)
{
    AvbABOps* ab_ops;
    AvbABData ab_data;
    AvbIOResult io_ret;
    size_t bootSlot = -1;

    avb_ops_uboot_init();
    ab_ops = avb_get_ab_ops();

    io_ret = ab_ops->read_ab_metadata(ab_ops, &ab_data);
    if (io_ret != AVB_IO_RESULT_OK)
    {
        printf("%s:%d: I/O error while loading A/B metadata.\n",__FILE__,__LINE__);
        bootSlot = -1;
        return bootSlot;
    }

    if (slot_is_bootable(&ab_data.slots[0]) &&
        slot_is_bootable(&ab_data.slots[1]))
    {
        if (ab_data.slots[1].priority > ab_data.slots[0].priority)
        {
            bootSlot = 1;
        } else
        {
            bootSlot = 0;
        }
    }
    else if (slot_is_bootable(&ab_data.slots[0]))
    {
        bootSlot = 0;
    }
    else if (slot_is_bootable(&ab_data.slots[1]))
    {
        bootSlot = 1;
    }
    else
    {
        printf("%s:%d: There is no bootable slot.\n",__FILE__,__LINE__);
        bootSlot = -1;
    }

    return bootSlot;
}

int ab_getSlotRetryCount(int slotNumber)
{
    AvbABOps* ab_ops;
    AvbABData ab_data;
    AvbIOResult io_ret;

    avb_ops_uboot_init();
    ab_ops = avb_get_ab_ops();

    io_ret = ab_ops->read_ab_metadata(ab_ops, &ab_data);
    if (io_ret != AVB_IO_RESULT_OK)
    {
        printf("%s:%d: I/O error while loading A/B metadata.\n",__FILE__,__LINE__);
        return -1;
    }

    return ab_data.slots[slotNumber].tries_remaining;
}

int ab_getSlotSuccessful(int slotNumber)
{
    AvbABOps* ab_ops;
    AvbABData ab_data;
    AvbIOResult io_ret;

    avb_ops_uboot_init();
    ab_ops = avb_get_ab_ops();

    io_ret = ab_ops->read_ab_metadata(ab_ops, &ab_data);
    if (io_ret != AVB_IO_RESULT_OK)
    {
        printf("%s:%d: I/O error while loading A/B metadata.\n",__FILE__,__LINE__);
        return -1;
    }

    return ab_data.slots[slotNumber].successful_boot;
}

int ab_getSlotUnbootable(int slotNumber)
{
    AvbABOps* ab_ops;
    AvbABData ab_data;
    AvbIOResult io_ret;

    avb_ops_uboot_init();
    ab_ops = avb_get_ab_ops();

    io_ret = ab_ops->read_ab_metadata(ab_ops, &ab_data);
    if (io_ret != AVB_IO_RESULT_OK)
    {
        printf("%s:%d: I/O error while loading A/B metadata.\n",__FILE__,__LINE__);
        return -1;
    }

    return (!slot_is_bootable(&ab_data.slots[slotNumber]));
}

int ab_setActiveSlot(int slotNumber)
{
    avb_ops_uboot_init();
    if(avb_ab_mark_slot_active(avb_get_ab_ops(),slotNumber) == AVB_IO_RESULT_OK)
    {
        return 0;
    }
    else
    {
        printf("%s:%d: set active slot fail.\n",__FILE__,__LINE__);
        return -1;
    }
}

bool ab_appendSlotSuffix(char* out_data, const char* prefix_str)
{
    size_t slot_index;

    slot_index = ab_getCurrentSlotIndex();
    if(slot_index >=0)
    {
        strcpy(out_data,prefix_str);
        strcat(out_data,slot_suffixes[slot_index]);
        return true;
    }
    else
    {
        printf("%s:%d: There is no bootable slot.\n",__FILE__,__LINE__);
        return false;
    }
}

#if !defined(NDEBUG) || defined(CC_CONSOLE_LOCK)
int avb_clearRollbackIndex(void)
{
    int ret = 0;
    uint8_t rollback_index_buffer[RPMB_DATA_SIZE] = {0};

    //flush cache
    avb_ops_flush_rpmb_cache();

    //clear rpmb block1
    ret = ubootRpmbWriteData(rollback_index_buffer,RPMB_AVB_GENERATION_1,1);
    if(ret)
    {
        printf("%s:%d:%s: Error, emmc write rpmb data fail.\n",__FILE__,__LINE__,__FUNCTION__);
        return -1;
    }
    //clear rpmb block2
    ret = ubootRpmbWriteData(rollback_index_buffer,RPMB_AVB_GENERATION_2,1);
    if(ret)
    {
        printf("%s:%d:%s: Error, emmc write rpmb data fail.\n",__FILE__,__LINE__,__FUNCTION__);
        return -1;
    }

    printf("%s: All rollback index data has been set to zero.\n",__FUNCTION__);

    return 0;
}
#endif

int do_avbab(cmd_tbl_t *cmdtp, int flag, int argc, char *argv[])
{
    int i = 0, ret = 0;

    if(argc == 1 || strcmp(argv[1],"?") == 0) // for help information.
    {
        printf("%s\n", cmdtp->usage);
    }
    else
    {
        if(strcmp(argv[1],"enable-verity") == 0)
        {
            if(argc == 2)
            {
                AvbABOps* ab_ops;
                bool device_is_unlocked = false;
                avb_ops_uboot_init();
                ab_ops = avb_get_ab_ops();
                ab_ops->ops->read_is_device_unlocked(ab_ops->ops, &device_is_unlocked);
                if(device_is_unlocked == true)
                {
                    #ifdef CC_SUPPORT_AB_UPDATE
                    avb_set_verity(ab_ops->ops,"_a",true);
                    avb_set_verity(ab_ops->ops,"_b",true);
                    #else
                    avb_set_verity(ab_ops->ops,"",true);
                    #endif
                }
                else
                {
                    printf("%s: Error, device state is locked, don't allow to on/off dm-verity.\n",__FUNCTION__);
                    ret = 1;
                }
            }
            else
            {
                printf("%s: Error, incorrect numbers of parameter for sub command: %s\n",__FUNCTION__,argv[1]);
                ret = 1;
            }
        }
        else if(strcmp(argv[1],"disable-verity") == 0)
        {
            if(argc == 2)
            {
                AvbABOps* ab_ops;
                bool device_is_unlocked = false;
                avb_ops_uboot_init();
                ab_ops = avb_get_ab_ops();
                ab_ops->ops->read_is_device_unlocked(ab_ops->ops, &device_is_unlocked);
                if(device_is_unlocked == true)
                {
                    #ifdef CC_SUPPORT_AB_UPDATE
                    avb_set_verity(ab_ops->ops,"_a",false);
                    avb_set_verity(ab_ops->ops,"_b",false);
                    #else
                    avb_set_verity(ab_ops->ops,"",false);
                    #endif
                }
                else
                {
                    printf("%s: Error, device state is locked, don't allow to on/off dm-verity.\n",__FUNCTION__);
                    ret = 1;
                }
            }
            else
            {
                printf("%s: Error, incorrect numbers of parameter for sub command: %s\n",__FUNCTION__,argv[1]);
                ret = 1;
            }
        }
    #ifdef CC_SUPPORT_AB_UPDATE
        else if(strcmp(argv[1],"set_active") == 0)
        {
            if(argc == 3)
            {
                if(strcmp(argv[2],"a") == 0 || strcmp(argv[2],"_a") == 0)
                {
                    if(ab_setActiveSlot(0))
                    {
                        ret = 1;
                    }
                }
                else if(strcmp(argv[2],"b") == 0 || strcmp(argv[2],"_b") == 0)
                {
                    if(ab_setActiveSlot(1))
                    {
                        ret = 1;
                    }
                }
                else
                {
                    printf("%s: Error, unknown parameter <%s> for sub command: %s\n",__FUNCTION__,argv[2],argv[1]);
                    ret = 1;
                }
            }
            else
            {
                printf("%s: Error, incorrect numbers of parameter for sub command: %s\n",__FUNCTION__,argv[1]);
                ret = 1;
            }
        }
    #endif
    #ifndef NDEBUG
        else if(strcmp(argv[1],"clear") == 0)
        {
            if(argc == 2)
            {
                if(avb_clearRollbackIndex())
                {
                    ret = 1;
                }
            }
            else
            {
                printf("%s: Error, incorrect numbers of parameter for sub command: %s\n",__FUNCTION__,argv[1]);
                ret = 1;
            }
        }
    #endif
        else
        {
            printf("%s: Error, unknown sub command: %s\n",__FUNCTION__,argv[1]);
            ret = 1;
        }

        for(i=0; i<argc; i++)
        {
            printf("%s ",argv[i]);
        }
        if(ret){
            printf("Fail !!\n");
        } else {
            printf("Done !!\n");
        }
    }

    return ret;
}

U_BOOT_CMD(avbab, 3, 1, do_avbab,
    // usage.
    "\n\t  enable-verity     - AVB2.0 enable dm-verity."
    "\n\t  disable-verity    - AVB2.0 disable dm-verity."
    #ifdef CC_SUPPORT_AB_UPDATE
    "\n\t  set_active [slot] - set slot a/b to active slot."
    #endif
    #ifndef NDEBUG
    "\n\t  clear             - Set all Rollback Index to zero."
    #endif
    "\n",
    );

