
#ifndef AVB_OPS_UBOOT_H_
#define AVB_OPS_UBOOT_H_

#include "../libavb_ab/libavb_ab.h"

void avb_ops_flush_rpmb_cache(void);
void avb_ops_uboot_init(void);
AvbABOps* avb_get_ab_ops(void);
AvbOps* avb_get_ops(void);

#endif

