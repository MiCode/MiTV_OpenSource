
#include <common.h>
#include <jffs2/jffs2.h>
#include <mmc.h>

#include "avb_ops_uboot.h"
#include "../libavb_ab/libavb_ab.h"
#include "../../../board/mt53xx_com/mt53xx_com_rpmb.h"

typedef struct RPMB_CACHE {
    RPMB_ADDR address;
    uint8_t data[RPMB_DATA_SIZE];
}RPMB_CACHE;

#define INVALID_RPMB_ADDR (-1)

#define BOOT_DEVICE_MAJOR (179)

AvbABOps avbAB_ops_user;
AvbOps avb_ops_user;

static RPMB_CACHE rpmb_cache = {INVALID_RPMB_ADDR};

int32_t ubootReadRpmb(uint8_t *data, RPMB_ADDR addr, uint32_t offset, uint32_t length)
{
    if (data == NULL)
    {
        printf("%s, Error, NULL pointer.\n");
        return -1;
    }

    if (offset + length > RPMB_DATA_SIZE)
    {
        printf("%s, Error, data offset or length is out of range.\n");
        return -2;
    }

    if (rpmb_cache.address != addr)
    {
        rpmb_cache.address = addr;
        if (ubootRpmbReadData(rpmb_cache.data, rpmb_cache.address))
        {
            printf("%s:%d:%s: Error, emmc read rpmb data fail.\n",__FILE__,__LINE__,__FUNCTION__);
            rpmb_cache.address = INVALID_RPMB_ADDR;
            return -3;
        }
    }

    memcpy(data,rpmb_cache.data+offset,length);

    return length;
}

int32_t ubootWriteRpmb(const uint8_t *data, RPMB_ADDR addr, uint32_t offset, uint32_t length)
{
    if (data == NULL)
    {
        printf("%s, Error, NULL pointer.\n");
        return -1;
    }

    if (offset + length > RPMB_DATA_SIZE)
    {
        printf("%s, Fail, data offset or length is out of range.\n");
        return -2;
    }

    if (rpmb_cache.address != addr)
    {
        rpmb_cache.address = addr;
        if (ubootRpmbReadData(rpmb_cache.data, rpmb_cache.address))
        {
            printf("%s:%d:%s: Error, emmc read rpmb data fail.\n",__FILE__,__LINE__,__FUNCTION__);
            rpmb_cache.address = INVALID_RPMB_ADDR;
            return -3;
        }
    }

    memcpy(rpmb_cache.data+offset,data,length);

    if (ubootRpmbWriteData(rpmb_cache.data, rpmb_cache.address, 1))
    {
        printf("%s:%d:%s: Error, emmc write rpmb data fail.\n",__FILE__,__LINE__,__FUNCTION__);
        rpmb_cache.address = INVALID_RPMB_ADDR;
        return -4;
    }

    return length;
}

void avb_ops_flush_rpmb_cache(void)
{
    rpmb_cache.address = INVALID_RPMB_ADDR;
    memset(rpmb_cache.data, 0, RPMB_DATA_SIZE);
}

static size_t avb_read_emmc(u64 offset, void* addr, size_t cnt)
{
    int r;
    struct mmc *mmc;

    mmc = find_mmc_device(CONFIG_SYS_MMC_ENV_DEV);
    if (!mmc)
    {
        puts("AVB Read: Have no MMC device.\n");
        return 0;
    }

    if (mmc_init(mmc))
    {
        puts("AVB Read: MMC init failed.\n");
        return 0;
    }

    r = mmc->block_dev.byte_read(CONFIG_SYS_MMC_ENV_DEV, offset, cnt, addr);
    if (r != cnt)
    {
        puts("AVB Read: MMC Read error.\n");
        return 0;
    }

    return cnt;
}

static size_t avb_write_emmc(u64 offset, void* addr, size_t cnt)
{
    int r;
    struct mmc *mmc;

    mmc = find_mmc_device(CONFIG_SYS_MMC_ENV_DEV);
    if (!mmc)
    {
        puts("AVB write: Have no MMC device.\n");
        return 0;
    }

    if (mmc_init(mmc))
    {
        puts("AVB write: MMC init failed.\n");
        return 0;
    }

    r = mmc->block_dev.byte_write(CONFIG_SYS_MMC_ENV_DEV, offset, cnt, addr);
    if (r != cnt)
    {
        puts("AVB write: MMC write error.\n");
        return 0;
    }

    return cnt;
}

static AvbIOResult read_from_partition(AvbOps* ops,
                                       const char* partition,
                                       int64_t offset,
                                       size_t num_bytes,
                                       void* buffer,
                                       size_t* out_num_read) {
    struct mtd_device *dev;
    struct part_info *partInfo;
    uint8_t partNum;
    AvbIOResult ret;

    if ((mtdparts_init() == 0) && (find_dev_and_part(partition, &dev, &partNum, &partInfo) == 0))
    {
        // If offset is negative, interprets its absolute value as the number of bytes from the end of the partition.
        if(offset < 0)
        {
            offset += partInfo->size;
        }

        if(offset < partInfo->size)
        {
            if((offset + num_bytes) > partInfo->size)
            {
                num_bytes = partInfo->size - offset;
            }
            if(offset == 0 && strncmp(partition, "vbmeta", 6) == 0)
            {   //for debug used.
                memset(buffer, 0xab, sizeof(AvbVBMetaImageHeader));
            }
            *out_num_read = avb_read_emmc(partInfo->offset+offset, buffer, num_bytes);
            if(num_bytes != *out_num_read)
            {
                printf("%s:%d:%s: Error, Read emmc fail.\n",__FILE__,__LINE__,__FUNCTION__);
                ret = AVB_IO_RESULT_ERROR_IO;
            }
            else
            {
                if(offset == 0
                    && strncmp(partition, "vbmeta", 6) == 0
                    && strncmp(buffer, AVB_MAGIC, AVB_MAGIC_LEN) != 0)
                {   //for debug used.
                    printf("%s:%s: Error, Avb VBMeta image header block is:\n", __FUNCTION__, partition);
                    printf("\n#====>> expected start with 41 56 42 30 <<====#\n\n");
                    avb_print_block(buffer, sizeof(AvbVBMetaImageHeader));
                    printf("\n");
                }
                ret = AVB_IO_RESULT_OK;
            }
        }
        else
        {
            printf("%s:%d:%s: Error, Read offset is out of partition size.\n",__FILE__,__LINE__,__FUNCTION__);
            ret = AVB_IO_RESULT_ERROR_RANGE_OUTSIDE_PARTITION;
        }
    }
    else
    {
        printf("%s:%d:%s: Error, there no partition named %s.\n",__FILE__,__LINE__,__FUNCTION__,partition);
        ret = AVB_IO_RESULT_ERROR_NO_SUCH_PARTITION;
    }

    return ret;
}

static AvbIOResult write_to_partition(AvbOps* ops,
                                      const char* partition,
                                      int64_t offset,
                                      size_t num_bytes,
                                      const void* buffer) {
    struct mtd_device *dev;
    struct part_info *partInfo;
    uint8_t partNum;
    size_t write_bytes;
    AvbIOResult ret;

    if ((mtdparts_init() == 0) && (find_dev_and_part(partition, &dev, &partNum, &partInfo) == 0))
    {
        if(offset < partInfo->size)
        {
            if((offset + num_bytes) > partInfo->size)
            {
                num_bytes = partInfo->size - offset;
            }

            write_bytes = avb_write_emmc(partInfo->offset+offset, buffer, num_bytes);
            if(num_bytes != write_bytes)
            {
                printf("%s:%d:%s: Error, Write emmc fail.\n",__FILE__,__LINE__,__FUNCTION__);
                ret = AVB_IO_RESULT_ERROR_IO;
            }
            else
            {
                ret = AVB_IO_RESULT_OK;
            }
        }
        else
        {
            printf("%s:%d:%s: Error, Write offset is out of partition size.\n",__FILE__,__LINE__,__FUNCTION__);
            ret = AVB_IO_RESULT_ERROR_RANGE_OUTSIDE_PARTITION;
        }
    }
    else
    {
        printf("%s:%d:%s: Error, there no partition named %s.\n",__FILE__,__LINE__,__FUNCTION__,partition);
        ret = AVB_IO_RESULT_ERROR_NO_SUCH_PARTITION;
    }

    return ret;
}

static AvbIOResult validate_vbmeta_public_key(AvbOps* ops,
                                          const uint8_t* public_key_data,
                                          size_t public_key_length,
                                          const uint8_t* public_key_metadata,
                                          size_t public_key_metadata_length,
                                          bool* out_is_trusted)
{
    uint8_t avb_public_key0[] = {CONFIG_ANDROID_SIGNATURE_PUBKEY};

    if(public_key_metadata != NULL || public_key_metadata_length != 0)
    {
        printf("%s: Error: public key metadata is not supported now.\n",__FUNCTION__);
        *out_is_trusted = false;
        return AVB_IO_RESULT_ERROR_IO;
    }

    if(sizeof(avb_public_key0) != public_key_length)
    {
        printf("%s: Warning: vbmeta public key is mismatch by key length.\n",__FUNCTION__);
        *out_is_trusted = false;
    }
    else if(memcmp(public_key_data, avb_public_key0, public_key_length) == 0)
    {
        *out_is_trusted = true;
    }
    else
    {
        printf("%s: Warning: vbmeta public key is mismatch by key value.\n",__FUNCTION__);
        *out_is_trusted = false;
    }

    return AVB_IO_RESULT_OK;
}

#ifdef CC_AVB_DISABLE_RBI
static AvbIOResult read_rollback_index(AvbOps* ops,
                                   size_t rollback_index_location,
                                   uint64_t* out_rollback_index)
{
    *out_rollback_index = 0;
    return AVB_IO_RESULT_OK;
}
static AvbIOResult write_rollback_index(AvbOps* ops,
                                    size_t rollback_index_location,
                                    uint64_t rollback_index)
{
    return AVB_IO_RESULT_OK;
}
#else
static AvbIOResult read_rollback_index(AvbOps* ops,
                                   size_t rollback_index_location,
                                   uint64_t* out_rollback_index)
{
    RPMB_ADDR rpmb_address = RPMB_AVB_GENERATION_1;
    int location_offset = 0;
    int32_t ret = 0;

    if(rollback_index_location < (RPMB_DATA_SIZE/sizeof(uint64_t)))
    {
        rpmb_address = RPMB_AVB_GENERATION_1;
        location_offset = rollback_index_location;
    }
    else if(rollback_index_location >= (RPMB_DATA_SIZE/sizeof(uint64_t)) && rollback_index_location < 2*(RPMB_DATA_SIZE/sizeof(uint64_t)))
    {
        rpmb_address = RPMB_AVB_GENERATION_2;
        location_offset = rollback_index_location - (RPMB_DATA_SIZE/sizeof(uint64_t));
    }
    else
    {
        printf("%s:%d:%s: Error, rollback index location is out of range.\n",__FILE__,__LINE__,__FUNCTION__);
        return AVB_IO_RESULT_ERROR_IO;
    }

#if defined(CC_CONSOLE_LOCK) && defined(CC_MAPLE_LOADER_UPGRADE_VERSION_CTRL_FLOW)
    extern int get_console_state(void);
    extern int get_package_ignore_flag(void);
    if (get_console_state() || get_package_ignore_flag())
    {
        *out_rollback_index = 0;
        printf("%s ignore: Location = %d, Index = 0x%llx.\n", __FUNCTION__, rollback_index_location, *out_rollback_index);
        return AVB_IO_RESULT_OK;
    }
#endif

    ret = ubootReadRpmb((uint8_t *)out_rollback_index,rpmb_address,location_offset*sizeof(uint64_t),sizeof(uint64_t));

    if(ret < 0)
    {
        printf("%s:%d:%s: Error, AVB read rpmb data fail.\n",__FILE__,__LINE__,__FUNCTION__);
        return AVB_IO_RESULT_ERROR_IO;
    }

    printf("%s done, Location: %d, Index: 0x%llx\n", __FUNCTION__, rollback_index_location, *out_rollback_index);

    return AVB_IO_RESULT_OK;
}

static AvbIOResult write_rollback_index(AvbOps* ops,
                                    size_t rollback_index_location,
                                    uint64_t rollback_index)
{
    RPMB_ADDR rpmb_address = RPMB_AVB_GENERATION_1;
    int location_offset = 0;
    int32_t ret = 0;

    if(rollback_index_location < (RPMB_DATA_SIZE/sizeof(uint64_t)))
    {
        rpmb_address = RPMB_AVB_GENERATION_1;
        location_offset = rollback_index_location;
    }
    else if(rollback_index_location >= (RPMB_DATA_SIZE/sizeof(uint64_t)) && rollback_index_location < 2*(RPMB_DATA_SIZE/sizeof(uint64_t)))
    {
        rpmb_address = RPMB_AVB_GENERATION_2;
        location_offset = rollback_index_location - (RPMB_DATA_SIZE/sizeof(uint64_t));
    }
    else
    {
        printf("%s:%d:%s: Error, rollback index location is out of range.\n",__FILE__,__LINE__,__FUNCTION__);
        return AVB_IO_RESULT_ERROR_IO;
    }

#if defined(CC_CONSOLE_LOCK) && defined(CC_MAPLE_LOADER_UPGRADE_VERSION_CTRL_FLOW)
    extern int get_console_state(void);
    if (get_console_state())
    {
        printf("%s ignore: Location = %d, Index = 0x%llx.\n", __FUNCTION__, rollback_index_location, rollback_index);
        return AVB_IO_RESULT_OK;
    }
#endif

    ret = ubootWriteRpmb((uint8_t *)&rollback_index,rpmb_address,location_offset*sizeof(uint64_t),sizeof(uint64_t));

    if(ret < 0)
    {
        printf("%s:%d:%s: Error, AVB write rpmb data fail.\n",__FILE__,__LINE__,__FUNCTION__);
        return AVB_IO_RESULT_ERROR_IO;
    }

    printf("%s done, Location: %d, Index: 0x%llx\n", __FUNCTION__, rollback_index_location, rollback_index);

    return AVB_IO_RESULT_OK;
}
#endif

static AvbIOResult read_is_device_unlocked(AvbOps* ops, bool* out_is_unlocked)
{
    char *dev_state = getenv("devicestate");

    if(dev_state != NULL && strcmp(dev_state, "unlock") == 0)
    {
        *out_is_unlocked = true;
    }
    else
    {
        *out_is_unlocked = false;
    }

    return AVB_IO_RESULT_OK;
}

static AvbIOResult get_unique_guid_for_partition(AvbOps* ops,
                                             const char* partition,
                                             char* guid_buf,
                                             size_t guid_buf_size)
{
    struct mtd_device *dev;
    struct part_info *partInfo;
    uint8_t partNum;
    char path_tmp[64] = {0};
    int copy_size = 0;

    if ((mtdparts_init() == 0) && (find_dev_and_part(partition, &dev, &partNum, &partInfo) == 0))
    {
        sprintf(path_tmp,"%d:%d",BOOT_DEVICE_MAJOR,(partNum+1));
        copy_size = (guid_buf_size < strlen(path_tmp))? guid_buf_size : strlen(path_tmp);
        strncpy(guid_buf, path_tmp, copy_size);
        guid_buf[copy_size] = '\0';
        return AVB_IO_RESULT_OK;
    }
    else
    {
        printf("%s: Error: there is no %s partition.\n",__FUNCTION__, partition);
        return AVB_IO_RESULT_ERROR_NO_SUCH_PARTITION;
    }
}

static AvbIOResult get_size_of_partition(AvbOps* ops,
                                         const char* partition,
                                         uint64_t* out_size_in_bytes) {
    struct mtd_device *dev;
    struct part_info *partInfo;
    uint8_t partNum;
    AvbIOResult ret;

    if ((mtdparts_init() == 0) && (find_dev_and_part(partition, &dev, &partNum, &partInfo) == 0))
    {
        *out_size_in_bytes = partInfo->size;
        ret = AVB_IO_RESULT_OK;
    }
    else
    {
        ret = AVB_IO_RESULT_ERROR_IO;
    }

    return ret;
}

void avb_ops_uboot_init(void) {
    static bool already_initial = false;
    AvbABOps* ab_ops;

    if(already_initial == true) {
        return;
    } else {
        already_initial = true;
    }

    memset(&avbAB_ops_user,0,sizeof(AvbABOps));
    memset(&avb_ops_user,0,sizeof(AvbOps));

    //1. initial ab_ops.
    ab_ops = &avbAB_ops_user;
    //2. initial members of ab_ops.
    ab_ops->ops = &avb_ops_user;
    ab_ops->read_ab_metadata = avb_ab_data_read;
    ab_ops->write_ab_metadata = avb_ab_data_write;
    //3. initial members of ab_ops->ops.
    ab_ops->ops->ab_ops = ab_ops;
    ab_ops->ops->read_from_partition = read_from_partition;
    ab_ops->ops->write_to_partition = write_to_partition;
    ab_ops->ops->validate_vbmeta_public_key = validate_vbmeta_public_key;
    ab_ops->ops->read_rollback_index = read_rollback_index;
    ab_ops->ops->write_rollback_index = write_rollback_index;
    ab_ops->ops->read_is_device_unlocked = read_is_device_unlocked;
    ab_ops->ops->get_unique_guid_for_partition = get_unique_guid_for_partition;
    ab_ops->ops->get_size_of_partition = get_size_of_partition;
}

AvbABOps* avb_get_ab_ops(void)
{
    return (&avbAB_ops_user);
}

AvbOps* avb_get_ops(void)
{
    return (&avb_ops_user);
}

