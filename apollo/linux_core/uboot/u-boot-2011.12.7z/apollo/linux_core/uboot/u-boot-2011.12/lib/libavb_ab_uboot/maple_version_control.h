#ifndef __MAPLE_VERSION_CONTROL__
#define __MAPLE_VERSION_CONTROL__

#include <common.h>
//return 0-locked, 1-unlocked.
int get_console_state(void);
void update_pkg_cfg_version(uint64_t version_dec);

#endif

