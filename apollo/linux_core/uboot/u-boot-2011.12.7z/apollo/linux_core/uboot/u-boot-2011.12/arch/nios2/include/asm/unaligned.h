#ifndef _ASM_NIOS2_UNALIGNED_H
#define _ASM_NIOS2_UNALIGNED_H

#include <asm-generic/unaligned.h>

#endif /* _ASM_NIOS2_UNALIGNED_H */
