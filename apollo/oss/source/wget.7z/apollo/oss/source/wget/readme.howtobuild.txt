export OSS_SRC=/.../apollo/oss/source
export OSS_LIB=/.../apollo/oss/library/gnuarm-5.5.0_neon_ca9/
export OSS_COMPILE_PRE=/mtkoss/gnuarm/gcc-arm-linux-gnu-5.5.0-ubuntu/x86_64/bin/arm-linux-gnueabi-
export PLATFORM_CFLAGS="-march=armv7-a -mtune=cortex-a9 -mfloat-abi=softfp -mfpu=neon-vfpv4 -fPIC"

cd $OSS_SRC/wget

make all install \
	CROSS_COMPILE=$OSS_COMPILE_PRE \
	PLATFORM_ARCH=i686 \
	OSS_LIB_ROOT=$OSS_LIB \
	WGET_VERSION=1.10.2 \
	OSS_OUTPUT=$OSS_SRC/wget/

# cd $OSS_LIB/wget/1.10.2 && cp bin/wget . && rm -rf bin etc info man share && "$OSS_COMPILE_PRE"strip --strip-unneeded -R .comment wget

