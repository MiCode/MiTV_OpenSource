#include <time.h>
int mtk_futimens (int, char const *, struct timespec const [2]);
int utimens (char const *, struct timespec const [2]);
